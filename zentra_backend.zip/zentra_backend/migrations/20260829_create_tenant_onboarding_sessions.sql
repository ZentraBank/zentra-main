CREATE TABLE IF NOT EXISTS tenant_onboarding_sessions (
  id CHAR(36) NOT NULL,

  tenant_id CHAR(36) NOT NULL,
  user_id CHAR(36) NOT NULL,

  token_hash VARCHAR(64) NOT NULL,

  expires_at DATETIME NOT NULL,

  consumed_at DATETIME NULL,

  created_at DATETIME NOT NULL
    DEFAULT CURRENT_TIMESTAMP,

  updated_at DATETIME NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),

  UNIQUE KEY uq_tenant_onboarding_token_hash (
    token_hash
  ),

  INDEX idx_tenant_onboarding_tenant (
    tenant_id
  ),

  INDEX idx_tenant_onboarding_user (
    user_id
  ),

  INDEX idx_tenant_onboarding_active (
    tenant_id,
    user_id,
    consumed_at,
    expires_at
  ),

  CONSTRAINT fk_tenant_onboarding_tenant
    FOREIGN KEY (tenant_id)
    REFERENCES tenants(id)
    ON DELETE CASCADE,

  CONSTRAINT fk_tenant_onboarding_user
    FOREIGN KEY (user_id)
    REFERENCES users(id)
    ON DELETE CASCADE
);