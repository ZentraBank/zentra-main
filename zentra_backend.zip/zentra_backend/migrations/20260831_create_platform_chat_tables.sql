CREATE TABLE platform_chat_conversations (
  id CHAR(36) NOT NULL,

  tenant_id CHAR(36) NOT NULL,

  status ENUM(
    'open',
    'closed'
  ) NOT NULL DEFAULT 'open',

  created_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP,

  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),

  UNIQUE KEY uq_platform_chat_conversation_tenant (
    tenant_id
  ),

  KEY idx_platform_chat_conversations_status (
    status
  ),

  KEY idx_platform_chat_conversations_updated (
    updated_at
  ),

  CONSTRAINT fk_platform_chat_conversation_tenant
    FOREIGN KEY (tenant_id)
    REFERENCES tenants(id)
    ON DELETE CASCADE
);


CREATE TABLE platform_chat_messages (
  id CHAR(36) NOT NULL,

  conversation_id CHAR(36) NOT NULL,

  sender_type ENUM(
    'tenant_user',
    'platform_user'
  ) NOT NULL,

  sender_id CHAR(36) NOT NULL,

  message TEXT NOT NULL,

  created_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (id),

  KEY idx_platform_chat_messages_conversation (
    conversation_id,
    created_at
  ),

  KEY idx_platform_chat_messages_sender (
    sender_type,
    sender_id
  ),

  CONSTRAINT fk_platform_chat_message_conversation
    FOREIGN KEY (conversation_id)
    REFERENCES platform_chat_conversations(id)
    ON DELETE CASCADE
);



CREATE TABLE platform_chat_read_states (
  id CHAR(36) NOT NULL,

  conversation_id CHAR(36) NOT NULL,

  actor_type ENUM(
    'tenant_user',
    'platform_user'
  ) NOT NULL,

  actor_id CHAR(36) NOT NULL,

  last_read_at DATETIME NULL,

  created_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP,

  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),

  UNIQUE KEY uq_platform_chat_read_state (
    conversation_id,
    actor_type,
    actor_id
  ),

  KEY idx_platform_chat_read_actor (
    actor_type,
    actor_id
  ),

  CONSTRAINT fk_platform_chat_read_conversation
    FOREIGN KEY (conversation_id)
    REFERENCES platform_chat_conversations(id)
    ON DELETE CASCADE
);