CREATE TABLE push_subscriptions (
  id CHAR(36) NOT NULL,

  tenant_id CHAR(36) NOT NULL,
  user_id CHAR(36) NOT NULL,

  endpoint TEXT NOT NULL,

  p256dh TEXT NOT NULL,
  auth_secret TEXT NOT NULL,

  user_agent VARCHAR(500) NULL,

  is_active BOOLEAN NOT NULL DEFAULT TRUE,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),

  UNIQUE KEY unique_push_endpoint (
    endpoint(255)
  ),

  KEY idx_push_subscriptions_user (
    tenant_id,
    user_id,
    is_active
  ),

  CONSTRAINT fk_push_subscriptions_tenant
    FOREIGN KEY (tenant_id)
    REFERENCES tenants(id)
    ON DELETE CASCADE,

  CONSTRAINT fk_push_subscriptions_user
    FOREIGN KEY (user_id)
    REFERENCES users(id)
    ON DELETE CASCADE
);