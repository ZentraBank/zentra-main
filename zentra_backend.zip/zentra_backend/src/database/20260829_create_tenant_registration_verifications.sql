CREATE TABLE IF NOT EXISTS tenant_registration_verifications (
  id CHAR(36) NOT NULL,

  email VARCHAR(254) NOT NULL,

  code_hash VARCHAR(255) NOT NULL,

  attempts INT UNSIGNED NOT NULL DEFAULT 0,

  verified_at DATETIME NULL,

  consumed_at DATETIME NULL,

  expires_at DATETIME NOT NULL,

  completion_token_hash VARCHAR(64) NULL,

  completion_token_expires_at DATETIME NULL,

  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

  updated_at DATETIME NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),

  INDEX idx_tenant_registration_email (
    email
  ),

  INDEX idx_tenant_registration_active (
    email,
    consumed_at,
    expires_at
  ),

  INDEX idx_tenant_registration_completion_token (
    completion_token_hash
  )
);