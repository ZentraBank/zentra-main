const router = require("express").Router();

const controller = require("./uploads.controller");

const {
  resolveTenantMiddleware,
} = require("../../middleware/tenant.middleware");

const {
  authenticate,
} = require("../../middleware/auth.middleware");

const {
  requireAllPermissions,
} = require("../../middleware/permission.middleware");

const {
  uploadImage,
} = require("./uploads.middleware");

router.use(resolveTenantMiddleware);
router.use(authenticate);

router.post(
  "/images",
  requireAllPermissions(
    "donations.donors.manage"
  ),
  uploadImage.single("image"),
  controller.uploadImage
);

module.exports = router;