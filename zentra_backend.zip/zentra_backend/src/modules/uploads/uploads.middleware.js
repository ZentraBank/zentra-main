const multer =
  require("multer");

const path =
  require("path");

const fs =
  require("fs");

const crypto =
  require("crypto");

const uploadDirectory =
  path.join(
    process.cwd(),
    "uploads",
    "images"
  );

fs.mkdirSync(
  uploadDirectory,
  {
    recursive: true,
  }
);

const storage =
  multer.diskStorage({
    destination: (
      req,
      file,
      cb
    ) => {
      cb(
        null,
        uploadDirectory
      );
    },

    filename: (
      req,
      file,
      cb
    ) => {
      const extension =
        path
          .extname(
            file.originalname
          )
          .toLowerCase();

      const filename =
        `${Date.now()}-${crypto.randomUUID()}${extension}`;

      cb(
        null,
        filename
      );
    },
  });

const fileFilter = (
  req,
  file,
  cb
) => {
  const allowedTypes = [
    "image/jpeg",
    "image/png",
    "image/webp",
  ];

  if (
    !allowedTypes.includes(
      file.mimetype
    )
  ) {
    return cb(
      new Error(
        "Only JPG, PNG and WebP images are allowed"
      )
    );
  }

  cb(
    null,
    true
  );
};

const uploadImage =
  multer({
    storage,

    fileFilter,

    limits: {
      fileSize:
        5 *
        1024 *
        1024,
    },
  });

module.exports = {
  uploadImage,
};