const ApiError =
  require(
    "../../utils/ApiError"
  );

const asyncHandler =
  require(
    "../../utils/asyncHandler"
  );

const {
  sendSuccess,
} =
  require(
    "../../utils/response"
  );

const uploadImage =
  asyncHandler(
    async (
      req,
      res
    ) => {
      if (!req.file) {
        throw ApiError.badRequest(
          "Image file is required"
        );
      }

      const relativeUrl =
        `/uploads/images/${req.file.filename}`;

      return sendSuccess(
        res,
        {
          message:
            "Image uploaded successfully",

          data: {
            url:
              relativeUrl,
          },
        },
        201
      );
    }
  );

module.exports = {
  uploadImage,
};