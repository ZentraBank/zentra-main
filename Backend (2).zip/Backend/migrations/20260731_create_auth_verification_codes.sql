CREATE TABLE IF NOT EXISTS auth_verification_codes (
  id CHAR(36) NOT NULL,
  tenant_id CHAR(36) NOT NULL,
  user_id CHAR(36) NULL,
  purpose ENUM('registration','password_reset') NOT NULL,
  destination VARCHAR(191) NOT NULL,
  code_hash VARCHAR(255) NOT NULL,
  payload_json JSON NULL,
  attempts INT UNSIGNED NOT NULL DEFAULT 0,
  expires_at DATETIME NOT NULL,
  consumed_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_auth_codes_lookup (tenant_id, purpose, destination),
  KEY idx_auth_codes_expiry (expires_at),
  CONSTRAINT fk_auth_codes_tenant FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE,
  CONSTRAINT fk_auth_codes_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
