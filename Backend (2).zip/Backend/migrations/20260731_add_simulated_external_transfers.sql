ALTER TABLE transfers
  ADD COLUMN transfer_type ENUM('internal','external') NOT NULL DEFAULT 'internal' AFTER destination_account_number,
  ADD COLUMN destination_account_name VARCHAR(150) NULL AFTER transfer_type,
  ADD COLUMN destination_bank_name VARCHAR(150) NULL AFTER destination_account_name,
  ADD COLUMN destination_bank_code VARCHAR(50) NULL AFTER destination_bank_name,
  ADD COLUMN settlement_mode ENUM('internal','simulation','provider') NOT NULL DEFAULT 'internal' AFTER destination_bank_code,
  ADD COLUMN is_simulated BOOLEAN NOT NULL DEFAULT FALSE AFTER settlement_mode;
