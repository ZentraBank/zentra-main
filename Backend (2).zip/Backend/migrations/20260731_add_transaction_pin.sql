ALTER TABLE users
  ADD COLUMN transaction_pin_hash VARCHAR(255) NULL AFTER password_hash,
  ADD COLUMN transaction_pin_failed_attempts INT NOT NULL DEFAULT 0 AFTER transaction_pin_hash,
  ADD COLUMN transaction_pin_locked_until DATETIME NULL AFTER transaction_pin_failed_attempts;
