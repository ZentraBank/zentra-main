CREATE TABLE IF NOT EXISTS card_purchase_requests (
  id CHAR(36) PRIMARY KEY,

  tenant_id CHAR(36) NOT NULL,
  user_id CHAR(36) NOT NULL,
  account_id CHAR(36) NOT NULL,

  card_type ENUM(
    'virtual',
    'physical',
    'celebrity',
    'cryptocurrency',
    'official',
    'merchant'
  ) NOT NULL,

  card_brand VARCHAR(30) NOT NULL DEFAULT 'Zentra',

  price DECIMAL(15,2) NOT NULL,
  currency CHAR(3) NOT NULL DEFAULT 'GBP',

  payment_method ENUM('cryptocurrency') NOT NULL DEFAULT 'cryptocurrency',
  payment_reference VARCHAR(120) NULL,
  payment_proof_url VARCHAR(1000) NULL,

  status ENUM(
    'pending',
    'approved',
    'rejected',
    'cancelled'
  ) NOT NULL DEFAULT 'pending',

  issued_card_id CHAR(36) NULL,

  reviewed_by CHAR(36) NULL,
  reviewed_at DATETIME NULL,
  rejection_reason VARCHAR(500) NULL,

  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  CONSTRAINT fk_card_purchase_request_tenant
    FOREIGN KEY (tenant_id)
    REFERENCES tenants(id)
    ON DELETE CASCADE,

  CONSTRAINT fk_card_purchase_request_user
    FOREIGN KEY (user_id)
    REFERENCES users(id)
    ON DELETE CASCADE,

  CONSTRAINT fk_card_purchase_request_account
    FOREIGN KEY (account_id)
    REFERENCES accounts(id)
    ON DELETE RESTRICT,

  CONSTRAINT fk_card_purchase_request_card
    FOREIGN KEY (issued_card_id)
    REFERENCES cards(id)
    ON DELETE SET NULL,

  CONSTRAINT fk_card_purchase_request_reviewer
    FOREIGN KEY (reviewed_by)
    REFERENCES users(id)
    ON DELETE SET NULL,

  INDEX idx_card_purchase_requests_customer (
    tenant_id,
    user_id,
    created_at
  ),

  INDEX idx_card_purchase_requests_status (
    tenant_id,
    status,
    created_at
  ),

  INDEX idx_card_purchase_requests_account (
    account_id
  )
);