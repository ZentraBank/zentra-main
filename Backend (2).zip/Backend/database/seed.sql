CREATE DATABASE IF NOT EXISTS zentrabank;
USE zentrabank;

CREATE TABLE tenants (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  slug VARCHAR(100) NOT NULL UNIQUE,
  domain VARCHAR(255) UNIQUE,
  logo_url VARCHAR(255),
  primary_color VARCHAR(20) DEFAULT '#111827',
  status ENUM('active', 'inactive', 'suspended') DEFAULT 'active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO tenants (name, slug, domain, primary_color)
VALUES ('ZentraBank', 'zentrabank', 'localhost', '#111827');

SELECT * FROM tenants;



ALTER TABLE tenants
ADD COLUMN subscription_status ENUM('trial', 'active', 'expired', 'suspended') DEFAULT 'trial';

CREATE TABLE IF NOT EXISTS subscriptions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  plan_name VARCHAR(100) NOT NULL,
  amount DECIMAL(15,2) NOT NULL,
  currency VARCHAR(10) DEFAULT 'USDT',
  status ENUM('pending', 'approved', 'rejected', 'expired') DEFAULT 'pending',
  payment_reference VARCHAR(150),
  payment_note TEXT,
  starts_at DATETIME NULL,
  ends_at DATETIME NULL,
  approved_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

  FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE,
  FOREIGN KEY (approved_by) REFERENCES users(id) ON DELETE SET NULL
);

