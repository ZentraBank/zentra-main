SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE IF NOT EXISTS platform_users (
  id CHAR(36) NOT NULL,
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  email VARCHAR(191) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  transaction_pin_hash VARCHAR(255) NULL,
  transaction_pin_failed_attempts INT NOT NULL DEFAULT 0,
  transaction_pin_locked_until DATETIME NULL,
  role_code ENUM('platform_superadmin','platform_support','platform_auditor') NOT NULL DEFAULT 'platform_superadmin',

  status ENUM(
    'pending',
    'active',
    'inactive',
    'suspended',
    'disabled'
  ) NOT NULL DEFAULT 'active',

  last_login_at DATETIME NULL,

  email_verified_at DATETIME NULL,
  last_login_at DATETIME NULL,

  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,
  deleted_at DATETIME NULL,

  PRIMARY KEY (id),
  UNIQUE KEY uk_platform_users_email (email),
  KEY idx_platform_users_status (status),
  KEY idx_platform_users_deleted_at (deleted_at)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS tenants (
  id CHAR(36) NOT NULL,

  name VARCHAR(150) NOT NULL,
  slug VARCHAR(120) NOT NULL,
  domain VARCHAR(191) NULL,

  app_name VARCHAR(150) NOT NULL,
  logo_url VARCHAR(500) NULL,

  primary_color VARCHAR(20) NOT NULL DEFAULT '#2447D8',
  secondary_color VARCHAR(20) NOT NULL DEFAULT '#111827',

  contact_email VARCHAR(191) NULL,
  contact_phone VARCHAR(50) NULL,

  country_code CHAR(2) NULL,
  default_currency CHAR(3) NOT NULL DEFAULT 'USD',
  timezone VARCHAR(100) NOT NULL DEFAULT 'UTC',

  status ENUM(
    'active',
    'inactive',
    'suspended'
  ) NOT NULL DEFAULT 'active',

  created_by_platform_user_id CHAR(36) NULL,

  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,
  deleted_at DATETIME NULL,

  PRIMARY KEY (id),

  UNIQUE KEY uk_tenants_slug (slug),
  UNIQUE KEY uk_tenants_domain (domain),

  KEY idx_tenants_status (status),
  KEY idx_tenants_deleted_at (deleted_at),
  KEY idx_tenants_creator (created_by_platform_user_id),

  CONSTRAINT fk_tenants_platform_creator
    FOREIGN KEY (created_by_platform_user_id)
    REFERENCES platform_users (id)
    ON UPDATE CASCADE
    ON DELETE SET NULL
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS tenant_settings (
  id CHAR(36) NOT NULL,
  tenant_id CHAR(36) NOT NULL,

  setting_key VARCHAR(150) NOT NULL,
  setting_value JSON NULL,

  is_public BOOLEAN NOT NULL DEFAULT FALSE,

  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),

  UNIQUE KEY uk_tenant_settings_key (
    tenant_id,
    setting_key
  ),

  KEY idx_tenant_settings_tenant (tenant_id),
  KEY idx_tenant_settings_public (
    tenant_id,
    is_public
  ),

  CONSTRAINT fk_tenant_settings_tenant
    FOREIGN KEY (tenant_id)
    REFERENCES tenants (id)
    ON UPDATE CASCADE
    ON DELETE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS tenant_features (
  id CHAR(36) NOT NULL,
  tenant_id CHAR(36) NOT NULL,

  feature_key VARCHAR(150) NOT NULL,
  is_enabled BOOLEAN NOT NULL DEFAULT TRUE,

  configuration JSON NULL,

  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),

  UNIQUE KEY uk_tenant_features_key (
    tenant_id,
    feature_key
  ),

  KEY idx_tenant_features_tenant (tenant_id),
  KEY idx_tenant_features_enabled (
    tenant_id,
    is_enabled
  ),

  CONSTRAINT fk_tenant_features_tenant
    FOREIGN KEY (tenant_id)
    REFERENCES tenants (id)
    ON UPDATE CASCADE
    ON DELETE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS users (
  id CHAR(36) NOT NULL,

  first_name VARCHAR(100) NOT NULL,
  middle_name VARCHAR(100) NULL,
  last_name VARCHAR(100) NOT NULL,

  email VARCHAR(191) NOT NULL,
  phone VARCHAR(50) NULL,
  password_hash VARCHAR(255) NOT NULL,
  transaction_pin_hash VARCHAR(255) NULL,
  transaction_pin_failed_attempts INT NOT NULL DEFAULT 0,
  transaction_pin_locked_until DATETIME NULL,

  avatar_url VARCHAR(500) NULL,

  status ENUM(
    'active',
    'inactive',
    'suspended',
    'pending'
  ) NOT NULL DEFAULT 'pending',

  email_verified_at DATETIME NULL,
  phone_verified_at DATETIME NULL,
  last_login_at DATETIME NULL,

  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,
  deleted_at DATETIME NULL,

  PRIMARY KEY (id),

  UNIQUE KEY uk_users_email (email),
  UNIQUE KEY uk_users_phone (phone),

  KEY idx_users_status (status),
  KEY idx_users_deleted_at (deleted_at),
  KEY idx_users_name (
    first_name,
    last_name
  )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS roles (
  id CHAR(36) NOT NULL,
  tenant_id CHAR(36) NULL,

  name VARCHAR(100) NOT NULL,
  code VARCHAR(100) NOT NULL,
  description VARCHAR(500) NULL,

  is_system BOOLEAN NOT NULL DEFAULT FALSE,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,

  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),

  UNIQUE KEY uk_roles_tenant_code (
    tenant_id,
    code
  ),

  KEY idx_roles_tenant (tenant_id),
  KEY idx_roles_active (is_active),

  CONSTRAINT fk_roles_tenant
    FOREIGN KEY (tenant_id)
    REFERENCES tenants (id)
    ON UPDATE CASCADE
    ON DELETE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS permissions (
  id CHAR(36) NOT NULL,

  name VARCHAR(150) NOT NULL,
  code VARCHAR(150) NOT NULL,
  description VARCHAR(500) NULL,
  module VARCHAR(100) NOT NULL,

  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),

  UNIQUE KEY uk_permissions_code (code),
  KEY idx_permissions_module (module)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS role_permissions (
  role_id CHAR(36) NOT NULL,
  permission_id CHAR(36) NOT NULL,

  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (
    role_id,
    permission_id
  ),

  KEY idx_role_permissions_permission (
    permission_id
  ),

  CONSTRAINT fk_role_permissions_role
    FOREIGN KEY (role_id)
    REFERENCES roles (id)
    ON UPDATE CASCADE
    ON DELETE CASCADE,

  CONSTRAINT fk_role_permissions_permission
    FOREIGN KEY (permission_id)
    REFERENCES permissions (id)
    ON UPDATE CASCADE
    ON DELETE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS tenant_memberships (
  id CHAR(36) NOT NULL,

  tenant_id CHAR(36) NOT NULL,
  user_id CHAR(36) NOT NULL,
  role_id CHAR(36) NOT NULL,

  employee_reference VARCHAR(100) NULL,

  status ENUM(
    'active',
    'inactive',
    'suspended',
    'pending'
  ) NOT NULL DEFAULT 'active',

  joined_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),

  UNIQUE KEY uk_membership_tenant_user (
    tenant_id,
    user_id
  ),

  UNIQUE KEY uk_membership_employee_reference (
    tenant_id,
    employee_reference
  ),

  KEY idx_memberships_user (user_id),
  KEY idx_memberships_role (role_id),
  KEY idx_memberships_status (
    tenant_id,
    status
  ),

  CONSTRAINT fk_memberships_tenant
    FOREIGN KEY (tenant_id)
    REFERENCES tenants (id)
    ON UPDATE CASCADE
    ON DELETE CASCADE,

  CONSTRAINT fk_memberships_user
    FOREIGN KEY (user_id)
    REFERENCES users (id)
    ON UPDATE CASCADE
    ON DELETE CASCADE,

  CONSTRAINT fk_memberships_role
    FOREIGN KEY (role_id)
    REFERENCES roles (id)
    ON UPDATE CASCADE
    ON DELETE RESTRICT
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS refresh_tokens (
  id CHAR(36) NOT NULL,

  user_id CHAR(36) NULL,
  platform_user_id CHAR(36) NULL,
  tenant_id CHAR(36) NULL,

  token_hash VARCHAR(255) NOT NULL,

  expires_at DATETIME NOT NULL,
  revoked_at DATETIME NULL,

  created_by_ip VARCHAR(64) NULL,
  revoked_by_ip VARCHAR(64) NULL,
  user_agent VARCHAR(500) NULL,

  replaced_by_token_id CHAR(36) NULL,

  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (id),

  UNIQUE KEY uk_refresh_tokens_hash (token_hash),

  KEY idx_refresh_tokens_user (user_id),
  KEY idx_refresh_tokens_platform_user (
    platform_user_id
  ),
  KEY idx_refresh_tokens_tenant (tenant_id),
  KEY idx_refresh_tokens_expires_at (expires_at),
  KEY idx_refresh_tokens_revoked_at (revoked_at),

  CONSTRAINT fk_refresh_tokens_user
    FOREIGN KEY (user_id)
    REFERENCES users (id)
    ON UPDATE CASCADE
    ON DELETE CASCADE,

  CONSTRAINT fk_refresh_tokens_platform_user
    FOREIGN KEY (platform_user_id)
    REFERENCES platform_users (id)
    ON UPDATE CASCADE
    ON DELETE CASCADE,

  CONSTRAINT fk_refresh_tokens_tenant
    FOREIGN KEY (tenant_id)
    REFERENCES tenants (id)
    ON UPDATE CASCADE
    ON DELETE CASCADE,

  CONSTRAINT fk_refresh_tokens_replacement
    FOREIGN KEY (replaced_by_token_id)
    REFERENCES refresh_tokens (id)
    ON UPDATE CASCADE
    ON DELETE SET NULL,

  CONSTRAINT chk_refresh_token_owner
    CHECK (
      (
        user_id IS NOT NULL
        AND platform_user_id IS NULL
      )
      OR
      (
        user_id IS NULL
        AND platform_user_id IS NOT NULL
      )
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS password_reset_tokens (
  id CHAR(36) NOT NULL,

  user_id CHAR(36) NULL,
  platform_user_id CHAR(36) NULL,
  tenant_id CHAR(36) NULL,

  token_hash VARCHAR(255) NOT NULL,
  expires_at DATETIME NOT NULL,
  used_at DATETIME NULL,

  requested_ip VARCHAR(64) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (id),

  UNIQUE KEY uk_password_reset_token_hash (
    token_hash
  ),

  KEY idx_password_reset_user (user_id),
  KEY idx_password_reset_platform_user (
    platform_user_id
  ),
  KEY idx_password_reset_tenant (tenant_id),
  KEY idx_password_reset_expiry (expires_at),

  CONSTRAINT fk_password_reset_user
    FOREIGN KEY (user_id)
    REFERENCES users (id)
    ON UPDATE CASCADE
    ON DELETE CASCADE,

  CONSTRAINT fk_password_reset_platform_user
    FOREIGN KEY (platform_user_id)
    REFERENCES platform_users (id)
    ON UPDATE CASCADE
    ON DELETE CASCADE,

  CONSTRAINT fk_password_reset_tenant
    FOREIGN KEY (tenant_id)
    REFERENCES tenants (id)
    ON UPDATE CASCADE
    ON DELETE CASCADE,

  CONSTRAINT chk_password_reset_owner
    CHECK (
      (
        user_id IS NOT NULL
        AND platform_user_id IS NULL
      )
      OR
      (
        user_id IS NULL
        AND platform_user_id IS NOT NULL
      )
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS audit_logs (
  id CHAR(36) NOT NULL,

  tenant_id CHAR(36) NULL,
  user_id CHAR(36) NULL,
  platform_user_id CHAR(36) NULL,

  action VARCHAR(150) NOT NULL,
  module VARCHAR(100) NOT NULL,

  entity_type VARCHAR(100) NULL,
  entity_id VARCHAR(100) NULL,

  description VARCHAR(1000) NULL,

  old_values JSON NULL,
  new_values JSON NULL,
  metadata JSON NULL,

  ip_address VARCHAR(64) NULL,
  user_agent VARCHAR(500) NULL,
  request_id VARCHAR(100) NULL,

  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (id),

  KEY idx_audit_logs_tenant (
    tenant_id,
    created_at
  ),

  KEY idx_audit_logs_user (
    user_id,
    created_at
  ),

  KEY idx_audit_logs_platform_user (
    platform_user_id,
    created_at
  ),

  KEY idx_audit_logs_action (
    action,
    created_at
  ),

  KEY idx_audit_logs_entity (
    entity_type,
    entity_id
  ),

  CONSTRAINT fk_audit_logs_tenant
    FOREIGN KEY (tenant_id)
    REFERENCES tenants (id)
    ON UPDATE CASCADE
    ON DELETE SET NULL,

  CONSTRAINT fk_audit_logs_user
    FOREIGN KEY (user_id)
    REFERENCES users (id)
    ON UPDATE CASCADE
    ON DELETE SET NULL,

  CONSTRAINT fk_audit_logs_platform_user
    FOREIGN KEY (platform_user_id)
    REFERENCES platform_users (id)
    ON UPDATE CASCADE
    ON DELETE SET NULL
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
CREATE TABLE IF NOT EXISTS chat_conversations (
  id CHAR(36) NOT NULL,
  tenant_id CHAR(36) NOT NULL,
  user_id CHAR(36) NOT NULL,
  subject VARCHAR(150) NOT NULL DEFAULT 'Support request',
  status ENUM('open','closed') NOT NULL DEFAULT 'open',
  last_message_at DATETIME NULL,
  closed_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  deleted_at DATETIME NULL,
  PRIMARY KEY (id),
  KEY idx_chat_conversations_tenant_user (tenant_id, user_id),
  KEY idx_chat_conversations_tenant_status (tenant_id, status),
  CONSTRAINT fk_chat_conversations_tenant FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE,
  CONSTRAINT fk_chat_conversations_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS chat_messages (
  id CHAR(36) NOT NULL,
  tenant_id CHAR(36) NOT NULL,
  conversation_id CHAR(36) NOT NULL,
  sender_id CHAR(36) NOT NULL,
  message TEXT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at DATETIME NULL,
  PRIMARY KEY (id),
  KEY idx_chat_messages_conversation_created (conversation_id, created_at),
  KEY idx_chat_messages_tenant (tenant_id),
  CONSTRAINT fk_chat_messages_tenant FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE,
  CONSTRAINT fk_chat_messages_conversation FOREIGN KEY (conversation_id) REFERENCES chat_conversations(id) ON DELETE CASCADE,
  CONSTRAINT fk_chat_messages_sender FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS auth_verification_codes (
  id CHAR(36) NOT NULL,
  tenant_id CHAR(36) NOT NULL,
  user_id CHAR(36) NULL,
  purpose ENUM('registration','password_reset') NOT NULL,
  destination VARCHAR(191) NOT NULL,
  code_hash VARCHAR(255) NOT NULL,
  payload_json JSON NULL,
  attempts INT UNSIGNED NOT NULL DEFAULT 0,
  expires_at DATETIME NOT NULL,
  consumed_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_auth_codes_lookup (tenant_id, purpose, destination),
  KEY idx_auth_codes_expiry (expires_at),
  CONSTRAINT fk_auth_codes_tenant FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE,
  CONSTRAINT fk_auth_codes_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
