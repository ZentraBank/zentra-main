CREATE TABLE IF NOT EXISTS subscription_plans (
  id CHAR(36) PRIMARY KEY,
  code VARCHAR(100) NOT NULL,
  name VARCHAR(180) NOT NULL,
  description TEXT NULL,

  billing_interval ENUM(
    'monthly',
    'quarterly',
    'annually',
    'custom'
  ) NOT NULL DEFAULT 'monthly',

  price DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  currency CHAR(3) NOT NULL DEFAULT 'USD',

  status ENUM(
    'draft',
    'active',
    'inactive',
    'retired'
  ) NOT NULL DEFAULT 'draft',

  is_public BOOLEAN NOT NULL DEFAULT FALSE,

  created_by CHAR(36) NOT NULL,
  updated_by CHAR(36) NOT NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_subscription_plan_code (code),
  KEY idx_subscription_plan_status (status)
);

CREATE TABLE IF NOT EXISTS subscription_plan_features (
  id CHAR(36) PRIMARY KEY,
  plan_id CHAR(36) NOT NULL,
  feature_code VARCHAR(180) NOT NULL,
  is_enabled BOOLEAN NOT NULL DEFAULT TRUE,
  usage_limit DECIMAL(18,2) NULL,
  metadata JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_plan_feature (
    plan_id,
    feature_code
  ),

  KEY idx_plan_feature_code (feature_code)
);

CREATE TABLE IF NOT EXISTS tenant_subscription_history (
  id CHAR(36) PRIMARY KEY,

  tenant_id CHAR(36) NOT NULL,
  subscription_id CHAR(36) NOT NULL,

  previous_plan_id CHAR(36) NULL,
  new_plan_id CHAR(36) NULL,

  action ENUM(
    'created',
    'upgraded',
    'downgraded',
    'renewed',
    'cancelled',
    'reactivated',
    'suspended',
    'expired'
  ) NOT NULL,

  previous_status VARCHAR(60) NULL,
  new_status VARCHAR(60) NULL,

  effective_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  reason TEXT NULL,

  performed_by CHAR(36) NOT NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  KEY idx_subscription_history_tenant (
    tenant_id,
    created_at
  ),

  KEY idx_subscription_history_subscription (
    subscription_id,
    created_at
  )
);

CREATE TABLE IF NOT EXISTS tenant_subscription_overrides (
  id CHAR(36) PRIMARY KEY,

  tenant_id CHAR(36) NOT NULL,
  subscription_id CHAR(36) NOT NULL,

  custom_price DECIMAL(18,2) NULL,
  custom_currency CHAR(3) NULL,
  custom_billing_interval ENUM(
    'monthly',
    'quarterly',
    'annually',
    'custom'
  ) NULL,

  contract_start_at TIMESTAMP NULL,
  contract_end_at TIMESTAMP NULL,

  notes TEXT NULL,
  updated_by CHAR(36) NOT NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_tenant_subscription_override (
    tenant_id,
    subscription_id
  )
);
