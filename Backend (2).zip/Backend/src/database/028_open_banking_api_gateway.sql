CREATE TABLE IF NOT EXISTS partner_applications (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  partner_name VARCHAR(255) NOT NULL,
  application_name VARCHAR(255) NOT NULL,
  application_type ENUM(
    'open_banking',
    'merchant',
    'fintech',
    'internal',
    'regulatory',
    'other'
  ) NOT NULL,

  client_id VARCHAR(180) NOT NULL,
  client_secret_hash VARCHAR(255) NOT NULL,

  public_key TEXT NULL,
  jwks_uri VARCHAR(1000) NULL,
  redirect_uris JSON NULL,

  environment ENUM(
    'sandbox',
    'production'
  ) NOT NULL DEFAULT 'sandbox',

  status ENUM(
    'pending',
    'active',
    'suspended',
    'revoked'
  ) NOT NULL DEFAULT 'pending',

  contact_name VARCHAR(255) NULL,
  contact_email VARCHAR(255) NULL,

  ip_allowlist JSON NULL,
  metadata JSON NULL,

  created_by CHAR(36) NOT NULL,
  approved_by CHAR(36) NULL,
  approved_at TIMESTAMP NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_partner_client_id (
    tenant_id,
    client_id
  ),

  KEY idx_partner_status (
    tenant_id,
    status,
    environment
  )
);

CREATE TABLE IF NOT EXISTS partner_application_scopes (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  partner_application_id CHAR(36) NOT NULL,

  scope_code VARCHAR(180) NOT NULL,
  status ENUM(
    'active',
    'inactive'
  ) NOT NULL DEFAULT 'active',

  granted_by CHAR(36) NOT NULL,
  granted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  UNIQUE KEY uq_partner_scope (
    partner_application_id,
    scope_code
  )
);

CREATE TABLE IF NOT EXISTS api_access_tokens (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  partner_application_id CHAR(36) NOT NULL,

  token_hash CHAR(64) NOT NULL,
  token_type VARCHAR(40) NOT NULL DEFAULT 'Bearer',

  scopes JSON NOT NULL,

  issued_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expires_at TIMESTAMP  NULL,
  revoked_at TIMESTAMP NULL,

  status ENUM(
    'active',
    'revoked',
    'expired'
  ) NOT NULL DEFAULT 'active',

  UNIQUE KEY uq_api_token_hash (
    token_hash
  ),

  KEY idx_api_token_partner (
    partner_application_id,
    status,
    expires_at
  )
);

CREATE TABLE IF NOT EXISTS open_banking_consents (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  user_id CHAR(36) NOT NULL,
  partner_application_id CHAR(36) NOT NULL,

  consent_reference VARCHAR(180) NOT NULL,
  consent_type ENUM(
    'account_information',
    'payment_initiation',
    'funds_confirmation',
    'transaction_history',
    'standing_orders',
    'direct_debits'
  ) NOT NULL,

  scopes JSON NOT NULL,
  account_ids JSON NULL,

  status ENUM(
    'pending',
    'authorised',
    'rejected',
    'revoked',
    'expired',
    'consumed'
  ) NOT NULL DEFAULT 'pending',

  valid_from TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expires_at TIMESTAMP NULL,

  authorised_at TIMESTAMP NULL,
  revoked_at TIMESTAMP NULL,
  revocation_reason VARCHAR(1000) NULL,

  strong_customer_authentication_reference VARCHAR(255) NULL,

  metadata JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_open_banking_consent_reference (
    tenant_id,
    consent_reference
  ),

  KEY idx_consent_user (
    tenant_id,
    user_id,
    status,
    expires_at
  ),

  KEY idx_consent_partner (
    tenant_id,
    partner_application_id,
    status
  )
);

CREATE TABLE IF NOT EXISTS partner_webhook_subscriptions (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  partner_application_id CHAR(36) NOT NULL,

  subscription_reference VARCHAR(180) NOT NULL,
  endpoint_url VARCHAR(1000) NOT NULL,
  event_types JSON NOT NULL,

  signing_secret_hash VARCHAR(255) NOT NULL,
  signing_algorithm VARCHAR(80) NOT NULL DEFAULT 'HMAC-SHA256',

  status ENUM(
    'active',
    'paused',
    'revoked'
  ) NOT NULL DEFAULT 'active',

  max_attempts INT UNSIGNED NOT NULL DEFAULT 10,
  timeout_seconds INT UNSIGNED NOT NULL DEFAULT 10,

  created_by CHAR(36) NOT NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_partner_webhook_reference (
    tenant_id,
    subscription_reference
  )
);

CREATE TABLE IF NOT EXISTS partner_webhook_deliveries (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  webhook_subscription_id CHAR(36) NOT NULL,

  event_id CHAR(36) NOT NULL,
  event_type VARCHAR(180) NOT NULL,

  payload JSON NOT NULL,
  signature VARCHAR(500) NULL,

  attempt_count INT UNSIGNED NOT NULL DEFAULT 0,

  status ENUM(
    'pending',
    'delivering',
    'delivered',
    'failed',
    'dead_letter'
  ) NOT NULL DEFAULT 'pending',

  response_status INT NULL,
  response_body MEDIUMTEXT NULL,

  next_attempt_at TIMESTAMP NULL,
  delivered_at TIMESTAMP NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_partner_webhook_event (
    webhook_subscription_id,
    event_id
  ),

  KEY idx_partner_webhook_delivery (
    tenant_id,
    status,
    next_attempt_at
  )
);

CREATE TABLE IF NOT EXISTS api_rate_limit_policies (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  policy_code VARCHAR(120) NOT NULL,
  name VARCHAR(180) NOT NULL,

  partner_application_id CHAR(36) NULL,
  route_pattern VARCHAR(500) NULL,

  requests_per_window INT UNSIGNED NOT NULL,
  window_seconds INT UNSIGNED NOT NULL,

  burst_limit INT UNSIGNED NULL,

  status ENUM(
    'active',
    'inactive'
  ) NOT NULL DEFAULT 'active',

  priority INT NOT NULL DEFAULT 100,

  created_by CHAR(36) NOT NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_rate_limit_policy (
    tenant_id,
    policy_code
  )
);

CREATE TABLE IF NOT EXISTS partner_api_request_logs (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  partner_application_id CHAR(36) NOT NULL,

  request_id VARCHAR(180) NOT NULL,
  method VARCHAR(16) NOT NULL,
  path VARCHAR(1000) NOT NULL,

  scopes JSON NULL,
  ip_address VARCHAR(80) NULL,
  user_agent VARCHAR(1000) NULL,

  request_hash CHAR(64) NULL,
  response_status INT NOT NULL,

  duration_ms INT UNSIGNED NULL,

  error_code VARCHAR(120) NULL,
  error_message VARCHAR(1000) NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  UNIQUE KEY uq_partner_request_id (
    tenant_id,
    request_id
  ),

  KEY idx_partner_request_logs (
    tenant_id,
    partner_application_id,
    created_at
  )
);
