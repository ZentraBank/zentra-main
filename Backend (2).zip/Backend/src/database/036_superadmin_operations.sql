CREATE TABLE IF NOT EXISTS platform_notification_recipients (
  id CHAR(36) PRIMARY KEY,
  notification_id CHAR(36) NOT NULL,
  platform_user_id CHAR(36) NOT NULL,

  is_read BOOLEAN NOT NULL DEFAULT FALSE,
  read_at TIMESTAMP NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  UNIQUE KEY uq_platform_notification_recipient (
    notification_id,
    platform_user_id
  ),

  KEY idx_platform_recipient_unread (
    platform_user_id,
    is_read,
    created_at
  )
);

CREATE TABLE IF NOT EXISTS platform_setting_history (
  id CHAR(36) PRIMARY KEY,

  setting_key VARCHAR(180) NOT NULL,
  previous_value JSON NULL,
  new_value JSON NOT NULL,

  changed_by CHAR(36) NOT NULL,
  reason TEXT NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  KEY idx_platform_setting_history (
    setting_key,
    created_at
  )
);

CREATE TABLE IF NOT EXISTS platform_saved_searches (
  id CHAR(36) PRIMARY KEY,
  platform_user_id CHAR(36) NOT NULL,

  search_type ENUM(
    'users',
    'accounts',
    'transactions'
  ) NOT NULL,

  name VARCHAR(180) NOT NULL,
  filters JSON NOT NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  KEY idx_platform_saved_search_user (
    platform_user_id,
    search_type
  )
);
