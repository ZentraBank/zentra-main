CREATE TABLE IF NOT EXISTS risk_rules (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  code VARCHAR(120) NOT NULL,
  name VARCHAR(180) NOT NULL,
  description VARCHAR(1000) NULL,

  event_type VARCHAR(120) NOT NULL,
  condition_type ENUM(
    'amount_threshold',
    'velocity',
    'new_device',
    'ip_change',
    'country_change',
    'failed_attempts',
    'dormant_account',
    'manual'
  ) NOT NULL,

  configuration JSON NOT NULL,
  score INT NOT NULL DEFAULT 0,

  decision ENUM(
    'allow',
    'allow_with_otp',
    'require_step_up',
    'require_admin_approval',
    'block'
  ) NULL,

  status ENUM(
    'active',
    'inactive',
    'draft'
  ) NOT NULL DEFAULT 'active',

  priority INT NOT NULL DEFAULT 100,

  created_by CHAR(36) NOT NULL,
  updated_by CHAR(36) NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_risk_rule_code (
    tenant_id,
    code
  ),

  KEY idx_risk_rules_event (
    tenant_id,
    event_type,
    status,
    priority
  )
);

CREATE TABLE IF NOT EXISTS device_fingerprints (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  user_id CHAR(36) NOT NULL,

  fingerprint_hash VARCHAR(255) NOT NULL,
  device_name VARCHAR(180) NULL,
  device_type VARCHAR(80) NULL,
  operating_system VARCHAR(120) NULL,
  browser VARCHAR(120) NULL,

  first_ip_address VARCHAR(64) NULL,
  last_ip_address VARCHAR(64) NULL,
  first_country CHAR(2) NULL,
  last_country CHAR(2) NULL,

  trust_status ENUM(
    'unknown',
    'trusted',
    'blocked'
  ) NOT NULL DEFAULT 'unknown',

  first_seen_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_seen_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  metadata JSON NULL,

  UNIQUE KEY uq_device_fingerprint (
    tenant_id,
    user_id,
    fingerprint_hash
  ),

  KEY idx_device_user (
    tenant_id,
    user_id,
    trust_status
  )
);

CREATE TABLE IF NOT EXISTS risk_events (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  user_id CHAR(36) NULL,

  event_type VARCHAR(120) NOT NULL,
  source_type VARCHAR(120) NULL,
  source_id CHAR(36) NULL,

  amount DECIMAL(18,2) NULL,
  currency CHAR(3) NULL,

  ip_address VARCHAR(64) NULL,
  country_code CHAR(2) NULL,
  device_fingerprint VARCHAR(255) NULL,

  payload JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  KEY idx_risk_events_user (
    tenant_id,
    user_id,
    event_type,
    created_at
  ),

  KEY idx_risk_events_source (
    tenant_id,
    source_type,
    source_id
  )
);

CREATE TABLE IF NOT EXISTS risk_evaluations (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  user_id CHAR(36) NULL,
  risk_event_id CHAR(36) NOT NULL,

  idempotency_key VARCHAR(160) NOT NULL,

  total_score INT NOT NULL DEFAULT 0,
  risk_level ENUM(
    'low',
    'medium',
    'high',
    'critical'
  ) NOT NULL,

  decision ENUM(
    'allow',
    'allow_with_otp',
    'require_step_up',
    'require_admin_approval',
    'block'
  ) NOT NULL,

  matched_rules JSON NULL,
  explanation JSON NULL,

  evaluated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  UNIQUE KEY uq_risk_evaluation_idempotency (
    tenant_id,
    idempotency_key
  ),

  KEY idx_risk_evaluations_user (
    tenant_id,
    user_id,
    evaluated_at
  )
);

CREATE TABLE IF NOT EXISTS fraud_cases (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  user_id CHAR(36) NULL,
  risk_evaluation_id CHAR(36) NOT NULL,

  case_reference VARCHAR(160) NOT NULL,
  title VARCHAR(220) NOT NULL,
  description VARCHAR(2000) NULL,

  severity ENUM(
    'low',
    'medium',
    'high',
    'critical'
  ) NOT NULL,

  status ENUM(
    'open',
    'investigating',
    'escalated',
    'resolved',
    'dismissed'
  ) NOT NULL DEFAULT 'open',

  assigned_to CHAR(36) NULL,
  resolution_note VARCHAR(2000) NULL,

  resolved_by CHAR(36) NULL,
  resolved_at TIMESTAMP NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_fraud_case_reference (
    tenant_id,
    case_reference
  ),

  KEY idx_fraud_cases_status (
    tenant_id,
    status,
    severity,
    created_at
  )
);

CREATE TABLE IF NOT EXISTS fraud_case_events (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  fraud_case_id CHAR(36) NOT NULL,

  event_type VARCHAR(120) NOT NULL,
  actor_user_id CHAR(36) NULL,
  note VARCHAR(2000) NULL,
  metadata JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  KEY idx_fraud_case_events_case (
    fraud_case_id,
    created_at
  )
);

CREATE TABLE IF NOT EXISTS blocked_network_indicators (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  indicator_type ENUM(
    'ip',
    'cidr',
    'country',
    'device_fingerprint'
  ) NOT NULL,

  indicator_value VARCHAR(255) NOT NULL,
  reason VARCHAR(1000) NULL,

  status ENUM(
    'active',
    'inactive'
  ) NOT NULL DEFAULT 'active',

  created_by CHAR(36) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  UNIQUE KEY uq_blocked_indicator (
    tenant_id,
    indicator_type,
    indicator_value
  )
);
