CREATE TABLE IF NOT EXISTS payment_mandates (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  user_id CHAR(36) NOT NULL,

  mandate_reference VARCHAR(180) NOT NULL,
  mandate_type ENUM(
    'direct_debit',
    'recurring_card',
    'standing_order',
    'wallet_autopay'
  ) NOT NULL,

  creditor_name VARCHAR(255) NOT NULL,
  creditor_reference VARCHAR(255) NULL,

  source_account_id CHAR(36) NOT NULL,
  source_ledger_account_id CHAR(36) NOT NULL,

  destination_account_id CHAR(36) NULL,
  destination_ledger_account_id CHAR(36) NULL,

  payment_rail_id CHAR(36) NULL,

  currency CHAR(3) NOT NULL,

  fixed_amount DECIMAL(18,2) NULL,
  maximum_amount DECIMAL(18,2) NULL,

  frequency ENUM(
    'daily',
    'weekly',
    'biweekly',
    'monthly',
    'quarterly',
    'semiannual',
    'annual',
    'custom'
  ) NOT NULL,

  interval_value INT UNSIGNED NULL,
  interval_unit ENUM(
    'day',
    'week',
    'month'
  ) NULL,

  start_date DATE NOT NULL,
  end_date DATE NULL,

  next_collection_date DATE NOT NULL,
  last_collection_date DATE NULL,

  execution_time TIME NULL,
  timezone VARCHAR(120) NOT NULL DEFAULT 'UTC',

  holiday_policy ENUM(
    'previous_business_day',
    'next_business_day',
    'skip'
  ) NOT NULL DEFAULT 'next_business_day',

  insufficient_funds_policy ENUM(
    'fail',
    'retry',
    'partial_not_allowed'
  ) NOT NULL DEFAULT 'retry',

  retry_count INT UNSIGNED NOT NULL DEFAULT 0,
  retry_interval_hours INT UNSIGNED NOT NULL DEFAULT 24,

  status ENUM(
    'pending_activation',
    'active',
    'paused',
    'cancelled',
    'expired',
    'completed',
    'failed'
  ) NOT NULL DEFAULT 'pending_activation',

  activation_method ENUM(
    'customer_authorisation',
    'staff_approval',
    'external_confirmation'
  ) NOT NULL DEFAULT 'customer_authorisation',

  authorised_at TIMESTAMP NULL,
  activated_at TIMESTAMP NULL,
  paused_at TIMESTAMP NULL,
  cancelled_at TIMESTAMP NULL,

  cancellation_reason VARCHAR(1000) NULL,

  metadata JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_payment_mandate_reference (
    tenant_id,
    mandate_reference
  ),

  KEY idx_payment_mandate_due (
    tenant_id,
    status,
    next_collection_date
  ),

  KEY idx_payment_mandate_customer (
    tenant_id,
    user_id,
    status
  )
);

CREATE TABLE IF NOT EXISTS mandate_authorisations (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  payment_mandate_id CHAR(36) NOT NULL,

  authorisation_type ENUM(
    'otp',
    'signed_document',
    'bank_confirmation',
    'staff_approval',
    'api_consent'
  ) NOT NULL,

  authorisation_reference VARCHAR(255) NULL,
  evidence_storage_key VARCHAR(1000) NULL,

  status ENUM(
    'pending',
    'confirmed',
    'rejected',
    'expired'
  ) NOT NULL DEFAULT 'pending',

  authorised_by CHAR(36) NULL,
  authorised_at TIMESTAMP NULL,

  metadata JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  KEY idx_mandate_authorisations (
    payment_mandate_id,
    status
  )
);

CREATE TABLE IF NOT EXISTS recurring_payment_schedules (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  payment_mandate_id CHAR(36) NOT NULL,

  scheduled_date DATE NOT NULL,
  scheduled_at TIMESTAMP NULL,

  amount DECIMAL(18,2) NOT NULL,
  currency CHAR(3) NOT NULL,

  status ENUM(
    'scheduled',
    'queued',
    'processing',
    'succeeded',
    'failed',
    'skipped',
    'cancelled',
    'retry_scheduled'
  ) NOT NULL DEFAULT 'scheduled',

  attempt_count INT UNSIGNED NOT NULL DEFAULT 0,
  next_retry_at TIMESTAMP NULL,

  payment_instruction_id CHAR(36) NULL,
  ledger_journal_id CHAR(36) NULL,

  failure_code VARCHAR(120) NULL,
  failure_message VARCHAR(1000) NULL,

  idempotency_key VARCHAR(180) NOT NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_recurring_schedule_idempotency (
    tenant_id,
    idempotency_key
  ),

  UNIQUE KEY uq_mandate_scheduled_date (
    tenant_id,
    payment_mandate_id,
    scheduled_date
  ),

  KEY idx_recurring_schedule_due (
    tenant_id,
    status,
    scheduled_date,
    next_retry_at
  )
);

CREATE TABLE IF NOT EXISTS mandate_events (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  payment_mandate_id CHAR(36) NOT NULL,

  event_type VARCHAR(140) NOT NULL,
  actor_user_id CHAR(36) NULL,
  actor_type ENUM(
    'customer',
    'staff',
    'system',
    'external_party'
  ) NOT NULL,

  previous_status VARCHAR(80) NULL,
  new_status VARCHAR(80) NULL,

  note VARCHAR(1000) NULL,
  metadata JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  KEY idx_mandate_events (
    payment_mandate_id,
    created_at
  )
);

CREATE TABLE IF NOT EXISTS business_calendars (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  code VARCHAR(120) NOT NULL,
  name VARCHAR(180) NOT NULL,
  country_code CHAR(2) NULL,
  timezone VARCHAR(120) NOT NULL DEFAULT 'UTC',

  weekend_days JSON NOT NULL,
  status ENUM(
    'active',
    'inactive'
  ) NOT NULL DEFAULT 'active',

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_business_calendar_code (
    tenant_id,
    code
  )
);

CREATE TABLE IF NOT EXISTS business_calendar_holidays (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  business_calendar_id CHAR(36) NOT NULL,

  holiday_date DATE NOT NULL,
  name VARCHAR(180) NOT NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  UNIQUE KEY uq_business_calendar_holiday (
    business_calendar_id,
    holiday_date
  )
);
