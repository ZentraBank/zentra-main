CREATE TABLE IF NOT EXISTS investment_products (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  name VARCHAR(160) NOT NULL,
  description VARCHAR(1000) NULL,

  currency CHAR(3) NOT NULL,
  minimum_amount DECIMAL(18,2) NOT NULL,
  maximum_amount DECIMAL(18,2) NULL,

  annual_rate DECIMAL(8,4) NOT NULL,
  duration_days INT UNSIGNED NOT NULL,

  payout_type ENUM(
    'at_maturity',
    'monthly',
    'quarterly'
  ) NOT NULL DEFAULT 'at_maturity',

  risk_level ENUM(
    'low',
    'medium',
    'high'
  ) NOT NULL DEFAULT 'low',

  status ENUM(
    'draft',
    'active',
    'paused',
    'closed'
  ) NOT NULL DEFAULT 'draft',

  created_by CHAR(36) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  KEY idx_investment_products_tenant_status (
    tenant_id,
    status,
    created_at
  )
);

CREATE TABLE IF NOT EXISTS investments (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  user_id CHAR(36) NOT NULL,
  product_id CHAR(36) NOT NULL,
  source_account_id CHAR(36) NOT NULL,

  principal DECIMAL(18,2) NOT NULL,
  currency CHAR(3) NOT NULL,
  annual_rate DECIMAL(8,4) NOT NULL,
  duration_days INT UNSIGNED NOT NULL,

  expected_return DECIMAL(18,2) NOT NULL,
  maturity_amount DECIMAL(18,2) NOT NULL,

  status ENUM(
    'pending',
    'active',
    'matured',
    'withdrawal_requested',
    'completed',
    'cancelled'
  ) NOT NULL DEFAULT 'pending',

  started_at TIMESTAMP NULL,
  maturity_date TIMESTAMP NULL,
  completed_at TIMESTAMP NULL,
  cancelled_at TIMESTAMP NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  KEY idx_investments_tenant_user (
    tenant_id,
    user_id,
    created_at
  ),

  KEY idx_investments_status_maturity (
    tenant_id,
    status,
    maturity_date
  )
);

CREATE TABLE IF NOT EXISTS investment_withdrawals (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  investment_id CHAR(36) NOT NULL,
  user_id CHAR(36) NOT NULL,
  destination_account_id CHAR(36) NOT NULL,

  amount DECIMAL(18,2) NOT NULL,
  currency CHAR(3) NOT NULL,

  status ENUM(
    'pending',
    'approved',
    'rejected',
    'completed'
  ) NOT NULL DEFAULT 'pending',

  reviewed_by CHAR(36) NULL,
  reviewed_at TIMESTAMP NULL,
  rejection_reason VARCHAR(1000) NULL,
  completed_at TIMESTAMP NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  KEY idx_investment_withdrawals_status (
    tenant_id,
    status,
    created_at
  )
);

CREATE TABLE IF NOT EXISTS investment_events (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  investment_id CHAR(36) NOT NULL,
  withdrawal_id CHAR(36) NULL,
  actor_user_id CHAR(36) NULL,
  event_type VARCHAR(100) NOT NULL,
  metadata JSON NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  KEY idx_investment_events_investment (
    investment_id,
    created_at
  )
);
