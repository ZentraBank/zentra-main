CREATE TABLE IF NOT EXISTS transfers (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  user_id CHAR(36) NOT NULL,
  source_account_id CHAR(36) NOT NULL,
  destination_account_id CHAR(36) NULL,
  destination_account_number VARCHAR(30) NOT NULL,
  transfer_type ENUM('internal','external') NOT NULL DEFAULT 'internal',
  destination_account_name VARCHAR(150) NULL,
  destination_bank_name VARCHAR(150) NULL,
  destination_bank_code VARCHAR(50) NULL,
  settlement_mode ENUM('internal','simulation','provider') NOT NULL DEFAULT 'internal',
  is_simulated BOOLEAN NOT NULL DEFAULT FALSE,
  amount DECIMAL(18,2) NOT NULL,
  currency CHAR(3) NOT NULL DEFAULT 'USD',
  description VARCHAR(255) NULL,
  status ENUM('pending','completed','failed','cancelled') NOT NULL DEFAULT 'pending',
  reference VARCHAR(80) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_transfers_reference (reference),
  KEY idx_transfers_tenant_user_created (tenant_id, user_id, created_at)
);

CREATE TABLE IF NOT EXISTS account_ledger_entries (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  account_id CHAR(36) NOT NULL,
  transfer_id CHAR(36) NULL,
  entry_type ENUM('debit','credit') NOT NULL,
  amount DECIMAL(18,2) NOT NULL,
  balance_after DECIMAL(18,2) NOT NULL,
  description VARCHAR(255) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_ledger_tenant_account_created (tenant_id, account_id, created_at),
  KEY idx_ledger_transfer (transfer_id)
);
