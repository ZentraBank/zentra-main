CREATE TABLE IF NOT EXISTS privacy_purposes (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  purpose_code VARCHAR(120) NOT NULL,
  purpose_name VARCHAR(255) NOT NULL,
  description TEXT NULL,

  lawful_basis ENUM(
    'consent',
    'contract',
    'legal_obligation',
    'vital_interests',
    'public_task',
    'legitimate_interests'
  ) NOT NULL,

  data_categories JSON NOT NULL,
  processing_activities JSON NOT NULL,

  retention_policy_id CHAR(36) NULL,

  status ENUM(
    'draft',
    'active',
    'retired'
  ) NOT NULL DEFAULT 'draft',

  created_by CHAR(36) NOT NULL,
  approved_by CHAR(36) NULL,
  approved_at TIMESTAMP NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_privacy_purpose (
    tenant_id,
    purpose_code
  )
);

CREATE TABLE IF NOT EXISTS customer_privacy_consents (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  user_id CHAR(36) NOT NULL,
  privacy_purpose_id CHAR(36) NOT NULL,

  consent_reference VARCHAR(180) NOT NULL,

  status ENUM(
    'pending',
    'granted',
    'withdrawn',
    'expired',
    'rejected'
  ) NOT NULL DEFAULT 'pending',

  consent_version VARCHAR(80) NOT NULL,
  consent_text_hash CHAR(64) NOT NULL,

  collection_channel ENUM(
    'web',
    'mobile',
    'branch',
    'call_centre',
    'api',
    'paper'
  ) NOT NULL,

  ip_address VARCHAR(80) NULL,
  user_agent VARCHAR(1000) NULL,

  granted_at TIMESTAMP NULL,
  withdrawn_at TIMESTAMP NULL,
  expires_at TIMESTAMP NULL,

  withdrawal_reason VARCHAR(1000) NULL,

  evidence_storage_key VARCHAR(1000) NULL,
  metadata JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_privacy_consent_reference (
    tenant_id,
    consent_reference
  ),

  KEY idx_privacy_consent_user (
    tenant_id,
    user_id,
    status
  )
);

CREATE TABLE IF NOT EXISTS data_subject_requests (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  user_id CHAR(36) NULL,

  request_reference VARCHAR(180) NOT NULL,

  request_type ENUM(
    'access',
    'rectification',
    'erasure',
    'restriction',
    'portability',
    'objection',
    'automated_decision_review'
  ) NOT NULL,

  request_channel ENUM(
    'web',
    'mobile',
    'branch',
    'call_centre',
    'email',
    'api',
    'paper'
  ) NOT NULL,

  identity_verification_status ENUM(
    'pending',
    'verified',
    'failed',
    'waived'
  ) NOT NULL DEFAULT 'pending',

  status ENUM(
    'received',
    'identity_verification',
    'in_review',
    'approved',
    'rejected',
    'processing',
    'completed',
    'cancelled',
    'overdue'
  ) NOT NULL DEFAULT 'received',

  request_details TEXT NULL,
  rejection_reason TEXT NULL,

  due_at TIMESTAMP NOT NULL,
  completed_at TIMESTAMP NULL,

  assigned_to CHAR(36) NULL,
  approved_by CHAR(36) NULL,

  response_storage_key VARCHAR(1000) NULL,
  response_hash CHAR(64) NULL,

  metadata JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_data_subject_request (
    tenant_id,
    request_reference
  ),

  KEY idx_data_subject_request_status (
    tenant_id,
    status,
    due_at
  )
);

CREATE TABLE IF NOT EXISTS data_subject_request_tasks (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  data_subject_request_id CHAR(36) NOT NULL,

  system_name VARCHAR(180) NOT NULL,
  task_type ENUM(
    'search',
    'export',
    'rectify',
    'delete',
    'anonymise',
    'restrict',
    'review'
  ) NOT NULL,

  status ENUM(
    'pending',
    'processing',
    'completed',
    'failed',
    'blocked'
  ) NOT NULL DEFAULT 'pending',

  source_reference VARCHAR(255) NULL,
  result_storage_key VARCHAR(1000) NULL,

  record_count BIGINT UNSIGNED NOT NULL DEFAULT 0,

  failure_message VARCHAR(2000) NULL,

  assigned_to CHAR(36) NULL,
  completed_at TIMESTAMP NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  KEY idx_dsr_tasks (
    data_subject_request_id,
    status
  )
);

CREATE TABLE IF NOT EXISTS data_retention_policies (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  policy_code VARCHAR(120) NOT NULL,
  policy_name VARCHAR(255) NOT NULL,

  data_category VARCHAR(180) NOT NULL,
  source_system VARCHAR(180) NOT NULL,
  source_table VARCHAR(180) NULL,

  retention_period_days INT UNSIGNED NOT NULL,

  disposition_action ENUM(
    'delete',
    'anonymise',
    'archive',
    'review'
  ) NOT NULL,

  trigger_event ENUM(
    'record_created',
    'account_closed',
    'relationship_ended',
    'transaction_completed',
    'consent_withdrawn',
    'custom'
  ) NOT NULL,

  trigger_field VARCHAR(180) NULL,

  legal_basis VARCHAR(1000) NULL,

  status ENUM(
    'draft',
    'active',
    'inactive',
    'retired'
  ) NOT NULL DEFAULT 'draft',

  created_by CHAR(36) NOT NULL,
  approved_by CHAR(36) NULL,
  approved_at TIMESTAMP NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_retention_policy (
    tenant_id,
    policy_code
  )
);

CREATE TABLE IF NOT EXISTS retention_execution_runs (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  retention_policy_id CHAR(36) NOT NULL,

  run_reference VARCHAR(180) NOT NULL,

  cutoff_at TIMESTAMP NOT NULL,

  status ENUM(
    'pending',
    'scanning',
    'awaiting_approval',
    'approved',
    'executing',
    'completed',
    'failed',
    'cancelled'
  ) NOT NULL DEFAULT 'pending',

  candidate_count BIGINT UNSIGNED NOT NULL DEFAULT 0,
  processed_count BIGINT UNSIGNED NOT NULL DEFAULT 0,
  failed_count BIGINT UNSIGNED NOT NULL DEFAULT 0,

  maker_user_id CHAR(36) NOT NULL,
  checker_user_id CHAR(36) NULL,

  failure_message VARCHAR(2000) NULL,

  started_at TIMESTAMP NULL,
  completed_at TIMESTAMP NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_retention_execution_run (
    tenant_id,
    run_reference
  )
);

CREATE TABLE IF NOT EXISTS retention_execution_items (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  retention_run_id CHAR(36) NOT NULL,

  source_system VARCHAR(180) NOT NULL,
  source_table VARCHAR(180) NOT NULL,
  source_record_id VARCHAR(255) NOT NULL,

  disposition_action VARCHAR(80) NOT NULL,

  status ENUM(
    'candidate',
    'approved',
    'processed',
    'failed',
    'excluded',
    'legal_hold'
  ) NOT NULL DEFAULT 'candidate',

  record_hash_before CHAR(64) NULL,
  record_hash_after CHAR(64) NULL,

  failure_message VARCHAR(2000) NULL,
  processed_at TIMESTAMP NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  UNIQUE KEY uq_retention_execution_item (
    retention_run_id,
    source_system,
    source_table,
    source_record_id
  )
);

CREATE TABLE IF NOT EXISTS privacy_legal_holds (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  hold_reference VARCHAR(180) NOT NULL,
  name VARCHAR(255) NOT NULL,
  reason TEXT NOT NULL,

  scope_type ENUM(
    'user',
    'account',
    'transaction',
    'case',
    'table',
    'custom'
  ) NOT NULL,

  scope_reference VARCHAR(500) NOT NULL,

  status ENUM(
    'active',
    'released'
  ) NOT NULL DEFAULT 'active',

  effective_at TIMESTAMP NOT NULL,
  released_at TIMESTAMP NULL,

  created_by CHAR(36) NOT NULL,
  released_by CHAR(36) NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  UNIQUE KEY uq_privacy_legal_hold (
    tenant_id,
    hold_reference
  ),

  KEY idx_privacy_legal_hold_scope (
    tenant_id,
    scope_type,
    scope_reference,
    status
  )
);

CREATE TABLE IF NOT EXISTS privacy_incidents (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  incident_reference VARCHAR(180) NOT NULL,
  title VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,

  severity ENUM(
    'low',
    'medium',
    'high',
    'critical'
  ) NOT NULL,

  incident_type ENUM(
    'unauthorised_access',
    'data_loss',
    'data_disclosure',
    'malware',
    'misdelivery',
    'insider',
    'third_party',
    'other'
  ) NOT NULL,

  affected_record_count BIGINT UNSIGNED NULL,
  affected_user_count BIGINT UNSIGNED NULL,
  data_categories JSON NULL,

  discovered_at TIMESTAMP NOT NULL,
  contained_at TIMESTAMP NULL,
  closed_at TIMESTAMP NULL,

  regulator_notification_required BOOLEAN NOT NULL DEFAULT FALSE,
  customer_notification_required BOOLEAN NOT NULL DEFAULT FALSE,

  regulator_notified_at TIMESTAMP NULL,
  customers_notified_at TIMESTAMP NULL,

  status ENUM(
    'open',
    'investigating',
    'contained',
    'notified',
    'closed'
  ) NOT NULL DEFAULT 'open',

  owner_user_id CHAR(36) NOT NULL,

  metadata JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_privacy_incident (
    tenant_id,
    incident_reference
  ),

  KEY idx_privacy_incident_status (
    tenant_id,
    status,
    severity
  )
);
