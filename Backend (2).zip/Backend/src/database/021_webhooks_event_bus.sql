CREATE TABLE IF NOT EXISTS domain_events (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NULL,

  event_type VARCHAR(160) NOT NULL,
  aggregate_type VARCHAR(120) NULL,
  aggregate_id CHAR(36) NULL,

  event_version INT UNSIGNED NOT NULL DEFAULT 1,
  idempotency_key VARCHAR(180) NOT NULL,

  payload JSON NOT NULL,
  metadata JSON NULL,

  status ENUM(
    'pending',
    'published',
    'failed'
  ) NOT NULL DEFAULT 'pending',

  occurred_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  published_at TIMESTAMP NULL,

  UNIQUE KEY uq_domain_event_idempotency (
    tenant_id,
    idempotency_key
  ),

  KEY idx_domain_events_status (
    status,
    occurred_at
  ),

  KEY idx_domain_events_type (
    tenant_id,
    event_type,
    occurred_at
  )
);

CREATE TABLE IF NOT EXISTS webhook_endpoints (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  name VARCHAR(180) NOT NULL,
  endpoint_url VARCHAR(1000) NOT NULL,
  secret_encrypted VARCHAR(2000) NOT NULL,

  subscribed_events JSON NOT NULL,

  status ENUM(
    'active',
    'paused',
    'disabled'
  ) NOT NULL DEFAULT 'active',

  timeout_ms INT UNSIGNED NOT NULL DEFAULT 10000,
  max_attempts INT UNSIGNED NOT NULL DEFAULT 8,

  created_by CHAR(36) NOT NULL,
  updated_by CHAR(36) NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  KEY idx_webhook_endpoints_tenant (
    tenant_id,
    status
  )
);

CREATE TABLE IF NOT EXISTS webhook_deliveries (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  webhook_endpoint_id CHAR(36) NOT NULL,
  domain_event_id CHAR(36) NOT NULL,

  delivery_key VARCHAR(220) NOT NULL,

  status ENUM(
    'pending',
    'processing',
    'delivered',
    'failed',
    'dead_letter'
  ) NOT NULL DEFAULT 'pending',

  attempt_count INT UNSIGNED NOT NULL DEFAULT 0,

  request_headers JSON NULL,
  request_body JSON NULL,

  response_status INT NULL,
  response_headers JSON NULL,
  response_body MEDIUMTEXT NULL,

  last_error VARCHAR(2000) NULL,

  next_attempt_at TIMESTAMP NULL,
  delivered_at TIMESTAMP NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_webhook_delivery_key (
    delivery_key
  ),

  KEY idx_webhook_delivery_retry (
    status,
    next_attempt_at
  ),

  KEY idx_webhook_delivery_endpoint (
    webhook_endpoint_id,
    created_at
  )
);

CREATE TABLE IF NOT EXISTS webhook_delivery_attempts (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  webhook_delivery_id CHAR(36) NOT NULL,
  attempt_number INT UNSIGNED NOT NULL,

  request_headers JSON NULL,
  request_body JSON NULL,

  response_status INT NULL,
  response_headers JSON NULL,
  response_body MEDIUMTEXT NULL,

  error_message VARCHAR(2000) NULL,
  duration_ms INT UNSIGNED NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  UNIQUE KEY uq_delivery_attempt_number (
    webhook_delivery_id,
    attempt_number
  )
);

CREATE TABLE IF NOT EXISTS webhook_replay_requests (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  webhook_endpoint_id CHAR(36) NULL,
  event_type VARCHAR(160) NULL,

  from_date TIMESTAMP NOT NULL,
  to_date TIMESTAMP NOT NULL,

  status ENUM(
    'pending',
    'processing',
    'completed',
    'failed'
  ) NOT NULL DEFAULT 'pending',

  requested_by CHAR(36) NOT NULL,
  replayed_count INT UNSIGNED NOT NULL DEFAULT 0,

  error_message VARCHAR(2000) NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  completed_at TIMESTAMP NULL
);
