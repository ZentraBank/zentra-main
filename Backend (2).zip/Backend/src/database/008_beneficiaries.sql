CREATE TABLE IF NOT EXISTS beneficiaries (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  user_id CHAR(36) NOT NULL,
  beneficiary_type ENUM('internal','external') NOT NULL DEFAULT 'internal',
  display_name VARCHAR(120) NOT NULL,
  account_name VARCHAR(160) NOT NULL,
  account_number VARCHAR(30) NOT NULL,
  bank_name VARCHAR(160) NULL,
  bank_code VARCHAR(40) NULL,
  currency CHAR(3) NOT NULL DEFAULT 'USD',
  internal_account_id CHAR(36) NULL,
  is_favourite BOOLEAN NOT NULL DEFAULT FALSE,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_beneficiary_user_account_bank (tenant_id,user_id,account_number,bank_code),
  KEY idx_beneficiaries_tenant_user (tenant_id,user_id,created_at),
  KEY idx_beneficiaries_internal_account (internal_account_id)
);

CREATE TABLE IF NOT EXISTS beneficiary_events (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  beneficiary_id CHAR(36) NOT NULL,
  user_id CHAR(36) NOT NULL,
  actor_user_id CHAR(36) NULL,
  event_type VARCHAR(80) NOT NULL,
  metadata JSON NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_beneficiary_events_beneficiary (beneficiary_id,created_at)
);
