CREATE TABLE IF NOT EXISTS platform_notifications (
  id CHAR(36) PRIMARY KEY,

  notification_type VARCHAR(120) NOT NULL,

  severity ENUM(
    'info',
    'success',
    'warning',
    'error',
    'critical'
  ) NOT NULL DEFAULT 'info',

  title VARCHAR(255) NOT NULL,
  message TEXT NOT NULL,

  tenant_id CHAR(36) NULL,

  entity_type VARCHAR(120) NULL,
  entity_id CHAR(36) NULL,

  created_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP,

  KEY idx_platform_notifications_type (
    notification_type,
    created_at
  ),

  KEY idx_platform_notifications_severity (
    severity,
    created_at
  ),

  KEY idx_platform_notifications_tenant (
    tenant_id,
    created_at
  ),

  CONSTRAINT fk_platform_notifications_tenant
    FOREIGN KEY (tenant_id)
    REFERENCES tenants(id)
    ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS platform_notification_recipients (
  id CHAR(36) PRIMARY KEY,

  notification_id CHAR(36) NOT NULL,
  platform_user_id CHAR(36) NOT NULL,

  is_read BOOLEAN NOT NULL DEFAULT FALSE,
  read_at TIMESTAMP NULL,

  created_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP,

  UNIQUE KEY uq_platform_notification_recipient (
    notification_id,
    platform_user_id
  ),

  KEY idx_platform_recipient_unread (
    platform_user_id,
    is_read,
    created_at
  ),

  CONSTRAINT fk_platform_recipient_notification
    FOREIGN KEY (notification_id)
    REFERENCES platform_notifications(id)
    ON DELETE CASCADE,

  CONSTRAINT fk_platform_recipient_user
    FOREIGN KEY (platform_user_id)
    REFERENCES platform_users(id)
    ON DELETE CASCADE
);