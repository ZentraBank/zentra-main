CREATE TABLE IF NOT EXISTS regulatory_authorities (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  code VARCHAR(120) NOT NULL,
  name VARCHAR(255) NOT NULL,
  country_code CHAR(2) NULL,

  submission_channel ENUM(
    'portal',
    'sftp',
    'api',
    'email',
    'manual'
  ) NOT NULL DEFAULT 'manual',

  endpoint_url VARCHAR(1000) NULL,
  public_key TEXT NULL,

  status ENUM(
    'active',
    'inactive'
  ) NOT NULL DEFAULT 'active',

  metadata JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_regulatory_authority (
    tenant_id,
    code
  )
);

CREATE TABLE IF NOT EXISTS regulatory_report_definitions (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  authority_id CHAR(36) NOT NULL,

  report_code VARCHAR(120) NOT NULL,
  report_name VARCHAR(255) NOT NULL,

  report_type ENUM(
    'prudential',
    'aml',
    'transactions',
    'capital',
    'liquidity',
    'customer_protection',
    'tax',
    'statistical',
    'other'
  ) NOT NULL,

  frequency ENUM(
    'daily',
    'weekly',
    'monthly',
    'quarterly',
    'semiannual',
    'annual',
    'adhoc'
  ) NOT NULL,

  submission_deadline_days INT UNSIGNED NOT NULL DEFAULT 0,
  timezone VARCHAR(120) NOT NULL DEFAULT 'UTC',

  output_format ENUM(
    'json',
    'csv',
    'xml',
    'xlsx',
    'pdf',
    'xbrl'
  ) NOT NULL DEFAULT 'csv',

  data_query_key VARCHAR(255) NOT NULL,
  validation_schema JSON NULL,

  version VARCHAR(80) NOT NULL DEFAULT '1.0',
  effective_from DATE NOT NULL,
  effective_to DATE NULL,

  retention_years INT UNSIGNED NOT NULL DEFAULT 7,

  status ENUM(
    'draft',
    'active',
    'retired'
  ) NOT NULL DEFAULT 'draft',

  created_by CHAR(36) NOT NULL,
  approved_by CHAR(36) NULL,
  approved_at TIMESTAMP NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_regulatory_report_definition (
    tenant_id,
    authority_id,
    report_code,
    version
  )
);

CREATE TABLE IF NOT EXISTS regulatory_report_runs (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  report_definition_id CHAR(36) NOT NULL,

  run_reference VARCHAR(180) NOT NULL,
  reporting_period_start DATE NOT NULL,
  reporting_period_end DATE NOT NULL,

  status ENUM(
    'pending',
    'extracting',
    'validating',
    'ready_for_review',
    'approved',
    'submitted',
    'accepted',
    'rejected',
    'failed',
    'cancelled'
  ) NOT NULL DEFAULT 'pending',

  record_count BIGINT UNSIGNED NOT NULL DEFAULT 0,
  total_amount DECIMAL(24,2) NULL,
  currency CHAR(3) NULL,

  generated_file_key VARCHAR(1000) NULL,
  generated_file_hash CHAR(64) NULL,

  validation_error_count INT UNSIGNED NOT NULL DEFAULT 0,
  validation_warning_count INT UNSIGNED NOT NULL DEFAULT 0,

  maker_user_id CHAR(36) NULL,
  checker_user_id CHAR(36) NULL,

  submitted_at TIMESTAMP NULL,
  accepted_at TIMESTAMP NULL,
  rejected_at TIMESTAMP NULL,

  external_submission_reference VARCHAR(255) NULL,
  failure_message VARCHAR(2000) NULL,

  metadata JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_regulatory_report_run (
    tenant_id,
    run_reference
  ),

  KEY idx_regulatory_report_run_status (
    tenant_id,
    status,
    reporting_period_end
  )
);

CREATE TABLE IF NOT EXISTS regulatory_report_records (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  report_run_id CHAR(36) NOT NULL,

  record_key VARCHAR(255) NOT NULL,
  record_type VARCHAR(120) NULL,

  source_table VARCHAR(180) NULL,
  source_record_id VARCHAR(180) NULL,

  payload JSON NOT NULL,

  validation_status ENUM(
    'valid',
    'warning',
    'invalid'
  ) NOT NULL DEFAULT 'valid',

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  UNIQUE KEY uq_regulatory_report_record (
    report_run_id,
    record_key
  ),

  KEY idx_regulatory_report_record_status (
    report_run_id,
    validation_status
  )
);

CREATE TABLE IF NOT EXISTS regulatory_validation_results (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  report_run_id CHAR(36) NOT NULL,
  report_record_id CHAR(36) NULL,

  severity ENUM(
    'info',
    'warning',
    'error'
  ) NOT NULL,

  rule_code VARCHAR(180) NOT NULL,
  field_path VARCHAR(500) NULL,

  message VARCHAR(2000) NOT NULL,
  actual_value TEXT NULL,
  expected_value TEXT NULL,

  resolved BOOLEAN NOT NULL DEFAULT FALSE,
  resolved_by CHAR(36) NULL,
  resolved_at TIMESTAMP NULL,
  resolution_note VARCHAR(2000) NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  KEY idx_regulatory_validation_run (
    report_run_id,
    severity,
    resolved
  )
);

CREATE TABLE IF NOT EXISTS regulatory_submissions (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  report_run_id CHAR(36) NOT NULL,
  authority_id CHAR(36) NOT NULL,

  submission_reference VARCHAR(180) NOT NULL,
  submission_channel VARCHAR(80) NOT NULL,

  request_payload JSON NULL,
  response_payload JSON NULL,

  response_status_code INT NULL,
  external_reference VARCHAR(255) NULL,

  status ENUM(
    'queued',
    'submitted',
    'accepted',
    'rejected',
    'failed'
  ) NOT NULL DEFAULT 'queued',

  attempt_count INT UNSIGNED NOT NULL DEFAULT 0,
  next_attempt_at TIMESTAMP NULL,

  submitted_by CHAR(36) NOT NULL,
  submitted_at TIMESTAMP NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_regulatory_submission_reference (
    tenant_id,
    submission_reference
  )
);

CREATE TABLE IF NOT EXISTS regulatory_evidence_archive (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  report_run_id CHAR(36) NOT NULL,

  evidence_type ENUM(
    'source_extract',
    'generated_report',
    'submission_receipt',
    'regulator_response',
    'approval_record',
    'supporting_document'
  ) NOT NULL,

  storage_key VARCHAR(1000) NOT NULL,
  content_hash CHAR(64) NOT NULL,
  encryption_key_reference VARCHAR(255) NULL,

  retention_until DATE NOT NULL,
  legal_hold BOOLEAN NOT NULL DEFAULT FALSE,

  metadata JSON NULL,

  created_by CHAR(36) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  KEY idx_regulatory_evidence_retention (
    tenant_id,
    retention_until,
    legal_hold
  )
);
