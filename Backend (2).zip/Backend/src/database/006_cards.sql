CREATE TABLE IF NOT EXISTS cards (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  user_id CHAR(36) NOT NULL,
  account_id CHAR(36) NOT NULL,
  card_type ENUM('virtual','physical','celebrity','cryptocurrency','official','merchant')
    NOT NULL DEFAULT 'virtual',
  card_brand VARCHAR(30) NOT NULL DEFAULT 'Zentra',
  masked_pan VARCHAR(25) NOT NULL,
  pan_last4 CHAR(4) NOT NULL,
  expiry_month TINYINT UNSIGNED NOT NULL,
  expiry_year SMALLINT UNSIGNED NOT NULL,
  status ENUM('pending','active','frozen','blocked','inactive','expired')
    NOT NULL DEFAULT 'pending',
  is_virtual BOOLEAN NOT NULL DEFAULT TRUE,
  daily_spend_limit DECIMAL(18,2) NULL,
  issued_at TIMESTAMP NULL,
  activated_at TIMESTAMP NULL,
  deactivated_at TIMESTAMP NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_cards_tenant_user (tenant_id,user_id,created_at),
  KEY idx_cards_tenant_account (tenant_id,account_id),
  UNIQUE KEY uq_cards_tenant_masked_pan (tenant_id,masked_pan)
);

CREATE TABLE IF NOT EXISTS card_events (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  card_id CHAR(36) NOT NULL,
  user_id CHAR(36) NOT NULL,
  actor_user_id CHAR(36) NULL,
  event_type VARCHAR(80) NOT NULL,
  metadata JSON NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_card_events_card_created (card_id,created_at)
);
