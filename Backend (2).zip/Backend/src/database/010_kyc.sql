CREATE TABLE IF NOT EXISTS kyc_profiles (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  user_id CHAR(36) NOT NULL,

  first_name VARCHAR(100) NOT NULL,
  middle_name VARCHAR(100) NULL,
  last_name VARCHAR(100) NOT NULL,
  date_of_birth DATE NOT NULL,
  nationality VARCHAR(100) NOT NULL,

  phone_number VARCHAR(40) NOT NULL,
  residential_address VARCHAR(500) NOT NULL,
  city VARCHAR(120) NOT NULL,
  state_region VARCHAR(120) NULL,
  postal_code VARCHAR(30) NULL,
  country VARCHAR(100) NOT NULL,

  identity_type ENUM(
    'passport',
    'national_id',
    'drivers_license',
    'residence_permit'
  ) NOT NULL,

  identity_number VARCHAR(120) NOT NULL,
  identity_expiry_date DATE NULL,

  status ENUM(
    'draft',
    'submitted',
    'under_review',
    'approved',
    'rejected',
    'expired'
  ) NOT NULL DEFAULT 'draft',

  risk_level ENUM(
    'low',
    'medium',
    'high'
  ) NULL,

  rejection_reason VARCHAR(1000) NULL,
  reviewed_by CHAR(36) NULL,
  submitted_at TIMESTAMP NULL,
  reviewed_at TIMESTAMP NULL,
  approved_at TIMESTAMP NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_kyc_profiles_tenant_user (
    tenant_id,
    user_id
  ),

  UNIQUE KEY uq_kyc_profiles_identity (
    tenant_id,
    identity_type,
    identity_number
  ),

  KEY idx_kyc_profiles_status (
    tenant_id,
    status,
    created_at
  )
);

CREATE TABLE IF NOT EXISTS kyc_documents (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  kyc_profile_id CHAR(36) NOT NULL,
  user_id CHAR(36) NOT NULL,

  document_type ENUM(
    'identity_front',
    'identity_back',
    'selfie',
    'proof_of_address',
    'supporting_document'
  ) NOT NULL,

  file_url VARCHAR(1000) NOT NULL,
  file_name VARCHAR(255) NULL,
  mime_type VARCHAR(120) NULL,

  status ENUM(
    'pending',
    'accepted',
    'rejected'
  ) NOT NULL DEFAULT 'pending',

  rejection_reason VARCHAR(1000) NULL,
  reviewed_by CHAR(36) NULL,
  reviewed_at TIMESTAMP NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  KEY idx_kyc_documents_profile (
    kyc_profile_id,
    created_at
  ),

  KEY idx_kyc_documents_user (
    tenant_id,
    user_id,
    created_at
  )
);

CREATE TABLE IF NOT EXISTS kyc_events (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  kyc_profile_id CHAR(36) NOT NULL,
  user_id CHAR(36) NOT NULL,
  actor_user_id CHAR(36) NULL,
  event_type VARCHAR(100) NOT NULL,
  metadata JSON NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  KEY idx_kyc_events_profile (
    kyc_profile_id,
    created_at
  )
);
