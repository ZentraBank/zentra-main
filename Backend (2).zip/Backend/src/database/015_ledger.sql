CREATE TABLE IF NOT EXISTS ledger_accounts (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  owner_type ENUM(
    'customer_account',
    'tenant',
    'system'
  ) NOT NULL,

  owner_id CHAR(36) NULL,
  code VARCHAR(120) NOT NULL,
  name VARCHAR(160) NOT NULL,

  currency CHAR(3) NOT NULL,
  normal_balance ENUM(
    'debit',
    'credit'
  ) NOT NULL,

  status ENUM(
    'active',
    'suspended',
    'closed'
  ) NOT NULL DEFAULT 'active',

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_ledger_account_code (
    tenant_id,
    code,
    currency
  ),

  KEY idx_ledger_accounts_owner (
    tenant_id,
    owner_type,
    owner_id
  )
);

CREATE TABLE IF NOT EXISTS ledger_journals (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  reference VARCHAR(160) NOT NULL,
  idempotency_key VARCHAR(160) NOT NULL,

  transaction_type VARCHAR(100) NOT NULL,
  description VARCHAR(500) NULL,

  status ENUM(
    'pending',
    'posted',
    'reversed',
    'failed'
  ) NOT NULL DEFAULT 'pending',

  source_type VARCHAR(100) NULL,
  source_id CHAR(36) NULL,

  posted_by CHAR(36) NULL,
  posted_at TIMESTAMP NULL,

  reversed_by CHAR(36) NULL,
  reversed_at TIMESTAMP NULL,
  reversal_journal_id CHAR(36) NULL,

  metadata JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_ledger_journal_reference (
    tenant_id,
    reference
  ),

  UNIQUE KEY uq_ledger_journal_idempotency (
    tenant_id,
    idempotency_key
  ),

  KEY idx_ledger_journals_source (
    tenant_id,
    source_type,
    source_id
  ),

  KEY idx_ledger_journals_status (
    tenant_id,
    status,
    created_at
  )
);

CREATE TABLE IF NOT EXISTS ledger_entries (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  journal_id CHAR(36) NOT NULL,
  ledger_account_id CHAR(36) NOT NULL,

  entry_type ENUM(
    'debit',
    'credit'
  ) NOT NULL,

  amount DECIMAL(18,2) NOT NULL,
  currency CHAR(3) NOT NULL,

  description VARCHAR(500) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  KEY idx_ledger_entries_journal (
    journal_id
  ),

  KEY idx_ledger_entries_account (
    tenant_id,
    ledger_account_id,
    created_at
  )
);

CREATE TABLE IF NOT EXISTS account_holds (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  account_id CHAR(36) NOT NULL,

  reference VARCHAR(160) NOT NULL,
  amount DECIMAL(18,2) NOT NULL,
  currency CHAR(3) NOT NULL,

  reason VARCHAR(500) NULL,

  status ENUM(
    'active',
    'captured',
    'released',
    'expired'
  ) NOT NULL DEFAULT 'active',

  expires_at TIMESTAMP NULL,
  captured_journal_id CHAR(36) NULL,

  created_by CHAR(36) NULL,
  released_by CHAR(36) NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_account_hold_reference (
    tenant_id,
    reference
  ),

  KEY idx_account_holds_account (
    tenant_id,
    account_id,
    status
  )
);

CREATE TABLE IF NOT EXISTS ledger_balance_snapshots (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  ledger_account_id CHAR(36) NOT NULL,

  debit_total DECIMAL(18,2) NOT NULL DEFAULT 0,
  credit_total DECIMAL(18,2) NOT NULL DEFAULT 0,
  balance DECIMAL(18,2) NOT NULL DEFAULT 0,

  snapshot_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  KEY idx_ledger_snapshots_account (
    tenant_id,
    ledger_account_id,
    snapshot_at
  )
);
