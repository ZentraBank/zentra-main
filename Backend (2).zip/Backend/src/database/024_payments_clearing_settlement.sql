CREATE TABLE IF NOT EXISTS payment_rails (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  code VARCHAR(120) NOT NULL,
  name VARCHAR(180) NOT NULL,

  rail_type ENUM(
    'internal',
    'ach',
    'rtgs',
    'instant',
    'card',
    'wire',
    'mobile_money',
    'other'
  ) NOT NULL,

  currency CHAR(3) NOT NULL,
  country_code CHAR(2) NULL,

  settlement_mode ENUM(
    'gross',
    'net',
    'deferred_net'
  ) NOT NULL,

  cutoff_time TIME NULL,
  timezone VARCHAR(120) NOT NULL DEFAULT 'UTC',

  minimum_amount DECIMAL(18,2) NULL,
  maximum_amount DECIMAL(18,2) NULL,

  settlement_ledger_account_id CHAR(36) NOT NULL,
  clearing_ledger_account_id CHAR(36) NOT NULL,
  fee_ledger_account_id CHAR(36) NULL,

  status ENUM(
    'active',
    'inactive',
    'maintenance'
  ) NOT NULL DEFAULT 'active',

  metadata JSON NULL,

  created_by CHAR(36) NOT NULL,
  updated_by CHAR(36) NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_payment_rail_code (
    tenant_id,
    code
  )
);

CREATE TABLE IF NOT EXISTS payment_instructions (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  rail_id CHAR(36) NOT NULL,
  user_id CHAR(36) NOT NULL,
  source_account_id CHAR(36) NOT NULL,

  source_ledger_account_id CHAR(36) NOT NULL,
  destination_ledger_account_id CHAR(36) NULL,

  idempotency_key VARCHAR(180) NOT NULL,
  payment_reference VARCHAR(180) NOT NULL,

  external_reference VARCHAR(255) NULL,

  direction ENUM(
    'outbound',
    'inbound'
  ) NOT NULL,

  payment_type ENUM(
    'credit_transfer',
    'debit_transfer',
    'refund',
    'return',
    'reversal'
  ) NOT NULL,

  amount DECIMAL(18,2) NOT NULL,
  fee_amount DECIMAL(18,2) NOT NULL DEFAULT 0,
  currency CHAR(3) NOT NULL,

  debtor_name VARCHAR(255) NULL,
  debtor_account_reference VARCHAR(255) NULL,
  debtor_bank_code VARCHAR(120) NULL,

  creditor_name VARCHAR(255) NOT NULL,
  creditor_account_reference VARCHAR(255) NOT NULL,
  creditor_bank_code VARCHAR(120) NULL,

  narration VARCHAR(500) NULL,

  status ENUM(
    'created',
    'validated',
    'pending_approval',
    'queued',
    'submitted',
    'accepted',
    'rejected',
    'cleared',
    'settled',
    'returned',
    'reversed',
    'failed',
    'cancelled'
  ) NOT NULL DEFAULT 'created',

  risk_decision VARCHAR(120) NULL,
  compliance_decision VARCHAR(120) NULL,
  approval_request_id CHAR(36) NULL,

  clearing_batch_id CHAR(36) NULL,
  settlement_batch_id CHAR(36) NULL,

  hold_id CHAR(36) NULL,
  ledger_journal_id CHAR(36) NULL,
  settlement_journal_id CHAR(36) NULL,
  reversal_journal_id CHAR(36) NULL,

  requested_execution_date DATE NULL,
  submitted_at TIMESTAMP NULL,
  accepted_at TIMESTAMP NULL,
  cleared_at TIMESTAMP NULL,
  settled_at TIMESTAMP NULL,
  failed_at TIMESTAMP NULL,

  failure_code VARCHAR(120) NULL,
  failure_message VARCHAR(1000) NULL,

  metadata JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_payment_instruction_idempotency (
    tenant_id,
    idempotency_key
  ),

  UNIQUE KEY uq_payment_instruction_reference (
    tenant_id,
    payment_reference
  ),

  KEY idx_payment_instruction_status (
    tenant_id,
    status,
    created_at
  ),

  KEY idx_payment_instruction_batch (
    tenant_id,
    clearing_batch_id
  )
);

CREATE TABLE IF NOT EXISTS clearing_batches (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  rail_id CHAR(36) NOT NULL,

  batch_reference VARCHAR(180) NOT NULL,
  clearing_date DATE NOT NULL,

  direction ENUM(
    'outbound',
    'inbound',
    'mixed'
  ) NOT NULL,

  item_count INT UNSIGNED NOT NULL DEFAULT 0,
  total_amount DECIMAL(18,2) NOT NULL DEFAULT 0,
  currency CHAR(3) NOT NULL,

  status ENUM(
    'open',
    'closed',
    'submitted',
    'accepted',
    'rejected',
    'cleared',
    'settled',
    'failed'
  ) NOT NULL DEFAULT 'open',

  external_batch_reference VARCHAR(255) NULL,

  opened_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  closed_at TIMESTAMP NULL,
  submitted_at TIMESTAMP NULL,
  cleared_at TIMESTAMP NULL,
  settled_at TIMESTAMP NULL,

  metadata JSON NULL,

  UNIQUE KEY uq_clearing_batch_reference (
    tenant_id,
    batch_reference
  ),

  KEY idx_clearing_batch_date (
    tenant_id,
    rail_id,
    clearing_date,
    status
  )
);

CREATE TABLE IF NOT EXISTS settlement_batches (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  rail_id CHAR(36) NOT NULL,

  settlement_reference VARCHAR(180) NOT NULL,
  settlement_date DATE NOT NULL,

  gross_debit_amount DECIMAL(18,2) NOT NULL DEFAULT 0,
  gross_credit_amount DECIMAL(18,2) NOT NULL DEFAULT 0,
  net_settlement_amount DECIMAL(18,2) NOT NULL DEFAULT 0,

  currency CHAR(3) NOT NULL,

  status ENUM(
    'pending',
    'calculated',
    'approved',
    'posted',
    'reconciled',
    'failed'
  ) NOT NULL DEFAULT 'pending',

  approval_request_id CHAR(36) NULL,
  ledger_journal_id CHAR(36) NULL,

  calculated_at TIMESTAMP NULL,
  approved_at TIMESTAMP NULL,
  posted_at TIMESTAMP NULL,
  reconciled_at TIMESTAMP NULL,

  failure_message VARCHAR(1000) NULL,
  metadata JSON NULL,

  UNIQUE KEY uq_settlement_reference (
    tenant_id,
    settlement_reference
  ),

  KEY idx_settlement_batch_status (
    tenant_id,
    rail_id,
    settlement_date,
    status
  )
);

CREATE TABLE IF NOT EXISTS payment_returns (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  original_payment_instruction_id CHAR(36) NOT NULL,
  return_payment_instruction_id CHAR(36) NULL,

  return_reference VARCHAR(180) NOT NULL,
  return_code VARCHAR(120) NOT NULL,
  return_reason VARCHAR(1000) NULL,

  amount DECIMAL(18,2) NOT NULL,
  currency CHAR(3) NOT NULL,

  status ENUM(
    'received',
    'validated',
    'posted',
    'rejected',
    'failed'
  ) NOT NULL DEFAULT 'received',

  ledger_journal_id CHAR(36) NULL,

  received_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  posted_at TIMESTAMP NULL,

  metadata JSON NULL,

  UNIQUE KEY uq_payment_return_reference (
    tenant_id,
    return_reference
  )
);

CREATE TABLE IF NOT EXISTS payment_status_events (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  payment_instruction_id CHAR(36) NOT NULL,

  previous_status VARCHAR(80) NULL,
  new_status VARCHAR(80) NOT NULL,

  actor_user_id CHAR(36) NULL,
  actor_type ENUM(
    'customer',
    'staff',
    'system',
    'external_network'
  ) NOT NULL,

  note VARCHAR(1000) NULL,
  metadata JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  KEY idx_payment_status_events (
    payment_instruction_id,
    created_at
  )
);
