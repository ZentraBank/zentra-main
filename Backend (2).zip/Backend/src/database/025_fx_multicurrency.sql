CREATE TABLE IF NOT EXISTS fx_rate_sources (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NULL,

  code VARCHAR(120) NOT NULL,
  name VARCHAR(180) NOT NULL,
  provider_type ENUM(
    'manual',
    'api',
    'central_bank',
    'market_data',
    'internal'
  ) NOT NULL,

  priority INT NOT NULL DEFAULT 100,
  status ENUM(
    'active',
    'inactive'
  ) NOT NULL DEFAULT 'active',

  metadata JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_fx_rate_source (
    tenant_id,
    code
  )
);

CREATE TABLE IF NOT EXISTS fx_rates (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NULL,
  rate_source_id CHAR(36) NOT NULL,

  base_currency CHAR(3) NOT NULL,
  quote_currency CHAR(3) NOT NULL,

  bid_rate DECIMAL(24,10) NOT NULL,
  ask_rate DECIMAL(24,10) NOT NULL,
  mid_rate DECIMAL(24,10) NOT NULL,

  effective_at TIMESTAMP NOT NULL,
  expires_at TIMESTAMP NULL,

  status ENUM(
    'active',
    'expired',
    'superseded'
  ) NOT NULL DEFAULT 'active',

  external_reference VARCHAR(255) NULL,
  metadata JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  KEY idx_fx_rates_pair (
    tenant_id,
    base_currency,
    quote_currency,
    status,
    effective_at
  )
);

CREATE TABLE IF NOT EXISTS fx_spread_rules (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  code VARCHAR(120) NOT NULL,
  name VARCHAR(180) NOT NULL,

  base_currency CHAR(3) NULL,
  quote_currency CHAR(3) NULL,
  customer_segment VARCHAR(120) NULL,
  transaction_type VARCHAR(120) NULL,

  spread_type ENUM(
    'basis_points',
    'percentage',
    'fixed'
  ) NOT NULL,

  spread_value DECIMAL(18,8) NOT NULL,

  minimum_fee DECIMAL(18,2) NULL,
  maximum_fee DECIMAL(18,2) NULL,

  priority INT NOT NULL DEFAULT 100,

  status ENUM(
    'active',
    'inactive',
    'draft'
  ) NOT NULL DEFAULT 'active',

  created_by CHAR(36) NOT NULL,
  updated_by CHAR(36) NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_fx_spread_rule (
    tenant_id,
    code
  )
);

CREATE TABLE IF NOT EXISTS fx_quotes (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  user_id CHAR(36) NOT NULL,

  quote_reference VARCHAR(180) NOT NULL,
  idempotency_key VARCHAR(180) NOT NULL,

  source_currency CHAR(3) NOT NULL,
  destination_currency CHAR(3) NOT NULL,

  source_amount DECIMAL(18,2) NOT NULL,
  destination_amount DECIMAL(18,2) NOT NULL,

  market_rate DECIMAL(24,10) NOT NULL,
  customer_rate DECIMAL(24,10) NOT NULL,

  spread_amount DECIMAL(18,2) NOT NULL DEFAULT 0,
  fee_amount DECIMAL(18,2) NOT NULL DEFAULT 0,

  rate_source_id CHAR(36) NOT NULL,
  spread_rule_id CHAR(36) NULL,

  status ENUM(
    'active',
    'accepted',
    'expired',
    'cancelled'
  ) NOT NULL DEFAULT 'active',

  expires_at TIMESTAMP NOT NULL,
  accepted_at TIMESTAMP NULL,

  metadata JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  UNIQUE KEY uq_fx_quote_reference (
    tenant_id,
    quote_reference
  ),

  UNIQUE KEY uq_fx_quote_idempotency (
    tenant_id,
    idempotency_key
  ),

  KEY idx_fx_quote_status (
    tenant_id,
    user_id,
    status,
    expires_at
  )
);

CREATE TABLE IF NOT EXISTS fx_conversions (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  user_id CHAR(36) NOT NULL,

  fx_quote_id CHAR(36) NOT NULL,
  conversion_reference VARCHAR(180) NOT NULL,

  source_account_id CHAR(36) NOT NULL,
  destination_account_id CHAR(36) NOT NULL,

  source_ledger_account_id CHAR(36) NOT NULL,
  destination_ledger_account_id CHAR(36) NOT NULL,

  fx_position_ledger_account_id CHAR(36) NOT NULL,
  fee_ledger_account_id CHAR(36) NULL,

  source_currency CHAR(3) NOT NULL,
  destination_currency CHAR(3) NOT NULL,

  source_amount DECIMAL(18,2) NOT NULL,
  destination_amount DECIMAL(18,2) NOT NULL,
  fee_amount DECIMAL(18,2) NOT NULL DEFAULT 0,

  customer_rate DECIMAL(24,10) NOT NULL,

  status ENUM(
    'pending',
    'posted',
    'reversed',
    'failed'
  ) NOT NULL DEFAULT 'pending',

  journal_id CHAR(36) NULL,
  reversal_journal_id CHAR(36) NULL,

  failure_message VARCHAR(1000) NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  posted_at TIMESTAMP NULL,

  UNIQUE KEY uq_fx_conversion_reference (
    tenant_id,
    conversion_reference
  ),

  UNIQUE KEY uq_fx_conversion_quote (
    tenant_id,
    fx_quote_id
  )
);

CREATE TABLE IF NOT EXISTS fx_revaluation_runs (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  run_reference VARCHAR(180) NOT NULL,
  valuation_currency CHAR(3) NOT NULL,
  valuation_date DATE NOT NULL,

  status ENUM(
    'pending',
    'processing',
    'completed',
    'failed'
  ) NOT NULL DEFAULT 'pending',

  total_assets DECIMAL(18,2) NOT NULL DEFAULT 0,
  total_liabilities DECIMAL(18,2) NOT NULL DEFAULT 0,
  unrealised_gain_loss DECIMAL(18,2) NOT NULL DEFAULT 0,

  gain_loss_ledger_account_id CHAR(36) NOT NULL,
  revaluation_ledger_account_id CHAR(36) NOT NULL,

  journal_id CHAR(36) NULL,
  failure_message VARCHAR(1000) NULL,

  created_by CHAR(36) NOT NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  completed_at TIMESTAMP NULL,

  UNIQUE KEY uq_fx_revaluation_run (
    tenant_id,
    run_reference
  )
);

CREATE TABLE IF NOT EXISTS fx_revaluation_items (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  revaluation_run_id CHAR(36) NOT NULL,

  ledger_account_id CHAR(36) NOT NULL,
  account_currency CHAR(3) NOT NULL,

  account_balance DECIMAL(18,2) NOT NULL,
  valuation_rate DECIMAL(24,10) NOT NULL,
  valuation_amount DECIMAL(18,2) NOT NULL,
  carrying_amount DECIMAL(18,2) NOT NULL,
  gain_loss_amount DECIMAL(18,2) NOT NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  KEY idx_fx_revaluation_items_run (
    revaluation_run_id
  )
);
