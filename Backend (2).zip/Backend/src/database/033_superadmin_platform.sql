CREATE TABLE IF NOT EXISTS platform_users (
  id CHAR(36) PRIMARY KEY,
  email VARCHAR(255) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  first_name VARCHAR(120) NOT NULL,
  last_name VARCHAR(120) NOT NULL,
  role_code ENUM('platform_superadmin','platform_support','platform_auditor') NOT NULL,
  status ENUM('pending','active','suspended','disabled') NOT NULL DEFAULT 'pending',
  last_login_at TIMESTAMP NULL,
  created_by CHAR(36) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS tenant_feature_overrides (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  feature_code VARCHAR(180) NOT NULL,
  is_enabled BOOLEAN NOT NULL,
  override_reason TEXT NULL,
  created_by CHAR(36) NOT NULL,
  approved_by CHAR(36) NULL,
  approved_at TIMESTAMP NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_tenant_feature_override (tenant_id, feature_code)
);

CREATE TABLE IF NOT EXISTS platform_audit_logs (
  id CHAR(36) PRIMARY KEY,
  actor_platform_user_id CHAR(36) NOT NULL,
  action_code VARCHAR(180) NOT NULL,
  tenant_id CHAR(36) NULL,
  entity_type VARCHAR(120) NULL,
  entity_id CHAR(36) NULL,
  old_values JSON NULL,
  new_values JSON NULL,
  ip_address VARCHAR(64) NULL,
  user_agent VARCHAR(1000) NULL,
  request_id VARCHAR(180) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_platform_audit_tenant (tenant_id, created_at),
  KEY idx_platform_audit_action (action_code, created_at)
);

CREATE TABLE IF NOT EXISTS platform_settings (
  id CHAR(36) PRIMARY KEY,
  setting_key VARCHAR(180) NOT NULL UNIQUE,
  setting_value JSON NOT NULL,
  is_secret BOOLEAN NOT NULL DEFAULT FALSE,
  description TEXT NULL,
  updated_by CHAR(36) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
