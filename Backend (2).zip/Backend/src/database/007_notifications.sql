CREATE TABLE IF NOT EXISTS notifications (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  user_id CHAR(36) NOT NULL,
  notification_type VARCHAR(80) NOT NULL,
  title VARCHAR(160) NOT NULL,
  message VARCHAR(1000) NOT NULL,
  entity_type VARCHAR(80) NULL,
  entity_id CHAR(36) NULL,
  priority ENUM('low','normal','high','urgent') NOT NULL DEFAULT 'normal',
  action_url VARCHAR(1000) NULL,
  metadata JSON NULL,
  is_read BOOLEAN NOT NULL DEFAULT FALSE,
  read_at TIMESTAMP NULL,
  is_archived BOOLEAN NOT NULL DEFAULT FALSE,
  archived_at TIMESTAMP NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_notifications_user_created (tenant_id,user_id,created_at),
  KEY idx_notifications_user_unread (tenant_id,user_id,is_read,is_archived)
);

CREATE TABLE IF NOT EXISTS notification_broadcasts (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  created_by CHAR(36) NOT NULL,
  audience_type ENUM('all_users','role','plan') NOT NULL,
  audience_value VARCHAR(120) NULL,
  title VARCHAR(160) NOT NULL,
  message VARCHAR(1000) NOT NULL,
  priority ENUM('low','normal','high','urgent') NOT NULL DEFAULT 'normal',
  action_url VARCHAR(1000) NULL,
  metadata JSON NULL,
  recipient_count INT UNSIGNED NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
