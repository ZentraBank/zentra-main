CREATE TABLE IF NOT EXISTS report_exports (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  requested_by CHAR(36) NOT NULL,

  report_type ENUM(
    'transfers',
    'accounts',
    'users',
    'subscriptions',
    'kyc',
    'loans',
    'investments',
    'donations'
  ) NOT NULL,

  format ENUM(
    'csv',
    'json'
  ) NOT NULL DEFAULT 'csv',

  status ENUM(
    'pending',
    'processing',
    'completed',
    'failed'
  ) NOT NULL DEFAULT 'pending',

  filters JSON NULL,
  file_name VARCHAR(255) NULL,
  file_url VARCHAR(1000) NULL,
  row_count INT UNSIGNED NULL,
  failure_reason VARCHAR(1000) NULL,

  started_at TIMESTAMP NULL,
  completed_at TIMESTAMP NULL,
  expires_at TIMESTAMP NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  KEY idx_report_exports_tenant_status (
    tenant_id,
    status,
    created_at
  ),

  KEY idx_report_exports_requested_by (
    tenant_id,
    requested_by,
    created_at
  )
);
