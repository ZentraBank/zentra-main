CREATE TABLE IF NOT EXISTS audit_logs (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NULL,
  actor_user_id CHAR(36) NULL,

  actor_type ENUM(
    'user',
    'admin',
    'system',
    'api'
  ) NOT NULL DEFAULT 'user',

  action VARCHAR(120) NOT NULL,
  entity_type VARCHAR(80) NULL,
  entity_id CHAR(36) NULL,

  request_method VARCHAR(12) NULL,
  request_path VARCHAR(1000) NULL,
  ip_address VARCHAR(64) NULL,
  user_agent VARCHAR(1000) NULL,

  status ENUM(
    'success',
    'failure'
  ) NOT NULL DEFAULT 'success',

  description VARCHAR(1000) NULL,
  metadata JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  KEY idx_audit_logs_tenant_created (
    tenant_id,
    created_at
  ),

  KEY idx_audit_logs_actor_created (
    actor_user_id,
    created_at
  ),

  KEY idx_audit_logs_entity (
    tenant_id,
    entity_type,
    entity_id
  ),

  KEY idx_audit_logs_action (
    tenant_id,
    action,
    created_at
  )
);
