CREATE TABLE IF NOT EXISTS virtual_account_programs (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  code VARCHAR(120) NOT NULL,
  name VARCHAR(180) NOT NULL,

  currency CHAR(3) NOT NULL,
  country_code CHAR(2) NULL,

  payment_rail_id CHAR(36) NULL,
  settlement_account_id CHAR(36) NOT NULL,
  settlement_ledger_account_id CHAR(36) NOT NULL,
  collection_clearing_ledger_account_id CHAR(36) NOT NULL,
  fee_ledger_account_id CHAR(36) NULL,

  account_number_prefix VARCHAR(40) NULL,
  account_number_length INT UNSIGNED NOT NULL DEFAULT 10,

  allocation_mode ENUM(
    'sequential',
    'random',
    'external'
  ) NOT NULL DEFAULT 'sequential',

  reconciliation_mode ENUM(
    'exact_reference',
    'account_number',
    'payer_reference',
    'manual'
  ) NOT NULL DEFAULT 'account_number',

  status ENUM(
    'active',
    'inactive',
    'maintenance'
  ) NOT NULL DEFAULT 'active',

  metadata JSON NULL,

  created_by CHAR(36) NOT NULL,
  updated_by CHAR(36) NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_virtual_account_program (
    tenant_id,
    code
  )
);

CREATE TABLE IF NOT EXISTS virtual_accounts (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  program_id CHAR(36) NOT NULL,

  owner_user_id CHAR(36) NULL,
  owner_business_id CHAR(36) NULL,

  master_account_id CHAR(36) NOT NULL,
  master_ledger_account_id CHAR(36) NOT NULL,

  virtual_account_reference VARCHAR(180) NOT NULL,
  account_number VARCHAR(120) NOT NULL,
  account_name VARCHAR(255) NOT NULL,

  external_account_reference VARCHAR(255) NULL,

  purpose VARCHAR(255) NULL,
  expected_payer_name VARCHAR(255) NULL,
  expected_payer_reference VARCHAR(255) NULL,

  fixed_amount DECIMAL(18,2) NULL,
  maximum_amount DECIMAL(18,2) NULL,
  currency CHAR(3) NOT NULL,

  collection_mode ENUM(
    'single_use',
    'reusable',
    'open_amount',
    'fixed_amount'
  ) NOT NULL DEFAULT 'reusable',

  expiry_at TIMESTAMP NULL,

  status ENUM(
    'pending',
    'active',
    'suspended',
    'expired',
    'closed'
  ) NOT NULL DEFAULT 'pending',

  total_collected DECIMAL(18,2) NOT NULL DEFAULT 0,
  collection_count BIGINT UNSIGNED NOT NULL DEFAULT 0,

  activated_at TIMESTAMP NULL,
  closed_at TIMESTAMP NULL,

  metadata JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_virtual_account_number (
    tenant_id,
    account_number
  ),

  UNIQUE KEY uq_virtual_account_reference (
    tenant_id,
    virtual_account_reference
  ),

  KEY idx_virtual_account_owner (
    tenant_id,
    owner_user_id,
    status
  ),

  KEY idx_virtual_account_master (
    tenant_id,
    master_account_id,
    status
  )
);

CREATE TABLE IF NOT EXISTS collection_transactions (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  virtual_account_id CHAR(36) NULL,
  program_id CHAR(36) NOT NULL,

  collection_reference VARCHAR(180) NOT NULL,
  external_reference VARCHAR(255) NOT NULL,
  idempotency_key VARCHAR(180) NOT NULL,

  payer_name VARCHAR(255) NULL,
  payer_account_reference VARCHAR(255) NULL,
  payer_bank_code VARCHAR(120) NULL,
  payer_reference VARCHAR(255) NULL,

  amount DECIMAL(18,2) NOT NULL,
  fee_amount DECIMAL(18,2) NOT NULL DEFAULT 0,
  net_amount DECIMAL(18,2) NOT NULL,

  currency CHAR(3) NOT NULL,

  status ENUM(
    'received',
    'matched',
    'unmatched',
    'pending_review',
    'posted',
    'reversed',
    'returned',
    'failed'
  ) NOT NULL DEFAULT 'received',

  match_method ENUM(
    'account_number',
    'exact_reference',
    'payer_reference',
    'manual',
    'unmatched'
  ) NOT NULL DEFAULT 'unmatched',

  confidence_score DECIMAL(7,4) NULL,

  received_at TIMESTAMP NOT NULL,
  matched_at TIMESTAMP NULL,
  posted_at TIMESTAMP NULL,

  ledger_journal_id CHAR(36) NULL,
  reversal_journal_id CHAR(36) NULL,

  failure_code VARCHAR(120) NULL,
  failure_message VARCHAR(1000) NULL,

  raw_payload JSON NULL,
  metadata JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_collection_idempotency (
    tenant_id,
    idempotency_key
  ),

  UNIQUE KEY uq_collection_external_reference (
    tenant_id,
    external_reference
  ),

  UNIQUE KEY uq_collection_reference (
    tenant_id,
    collection_reference
  ),

  KEY idx_collection_status (
    tenant_id,
    status,
    received_at
  ),

  KEY idx_collection_virtual_account (
    tenant_id,
    virtual_account_id,
    received_at
  )
);

CREATE TABLE IF NOT EXISTS collection_match_candidates (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  collection_transaction_id CHAR(36) NOT NULL,
  virtual_account_id CHAR(36) NOT NULL,

  match_method VARCHAR(120) NOT NULL,
  confidence_score DECIMAL(7,4) NOT NULL,
  explanation VARCHAR(1000) NULL,

  selected BOOLEAN NOT NULL DEFAULT FALSE,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  KEY idx_collection_candidates (
    collection_transaction_id,
    confidence_score
  )
);

CREATE TABLE IF NOT EXISTS sweep_rules (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  virtual_account_program_id CHAR(36) NULL,
  virtual_account_id CHAR(36) NULL,

  code VARCHAR(120) NOT NULL,
  name VARCHAR(180) NOT NULL,

  sweep_type ENUM(
    'immediate',
    'end_of_day',
    'threshold',
    'scheduled'
  ) NOT NULL,

  threshold_amount DECIMAL(18,2) NULL,
  retain_amount DECIMAL(18,2) NOT NULL DEFAULT 0,

  destination_account_id CHAR(36) NOT NULL,
  destination_ledger_account_id CHAR(36) NOT NULL,

  frequency VARCHAR(120) NULL,
  execution_time TIME NULL,
  timezone VARCHAR(120) NOT NULL DEFAULT 'UTC',

  status ENUM(
    'active',
    'inactive',
    'draft'
  ) NOT NULL DEFAULT 'active',

  priority INT NOT NULL DEFAULT 100,

  created_by CHAR(36) NOT NULL,
  updated_by CHAR(36) NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_sweep_rule_code (
    tenant_id,
    code
  )
);

CREATE TABLE IF NOT EXISTS sweep_executions (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  sweep_rule_id CHAR(36) NOT NULL,

  execution_reference VARCHAR(180) NOT NULL,
  idempotency_key VARCHAR(180) NOT NULL,

  virtual_account_id CHAR(36) NOT NULL,

  source_ledger_account_id CHAR(36) NOT NULL,
  destination_ledger_account_id CHAR(36) NOT NULL,

  amount DECIMAL(18,2) NOT NULL,
  currency CHAR(3) NOT NULL,

  status ENUM(
    'pending',
    'posted',
    'failed',
    'reversed'
  ) NOT NULL DEFAULT 'pending',

  journal_id CHAR(36) NULL,
  reversal_journal_id CHAR(36) NULL,

  failure_message VARCHAR(1000) NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  posted_at TIMESTAMP NULL,

  UNIQUE KEY uq_sweep_execution_idempotency (
    tenant_id,
    idempotency_key
  )
);

CREATE TABLE IF NOT EXISTS collection_reconciliation_runs (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  program_id CHAR(36) NOT NULL,

  run_reference VARCHAR(180) NOT NULL,
  reconciliation_date DATE NOT NULL,

  status ENUM(
    'pending',
    'processing',
    'completed',
    'failed'
  ) NOT NULL DEFAULT 'pending',

  external_total DECIMAL(18,2) NOT NULL DEFAULT 0,
  internal_total DECIMAL(18,2) NOT NULL DEFAULT 0,
  variance_amount DECIMAL(18,2) NOT NULL DEFAULT 0,

  matched_count BIGINT UNSIGNED NOT NULL DEFAULT 0,
  unmatched_count BIGINT UNSIGNED NOT NULL DEFAULT 0,

  failure_message VARCHAR(1000) NULL,

  created_by CHAR(36) NOT NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  completed_at TIMESTAMP NULL,

  UNIQUE KEY uq_collection_reconciliation_run (
    tenant_id,
    run_reference
  )
);
