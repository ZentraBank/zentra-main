CREATE TABLE IF NOT EXISTS platform_refresh_tokens (
  id CHAR(36) PRIMARY KEY,
  platform_user_id CHAR(36) NOT NULL,

  token_hash VARCHAR(255) NOT NULL,
  device_name VARCHAR(255) NULL,
  ip_address VARCHAR(64) NULL,
  user_agent VARCHAR(1000) NULL,

  expires_at TIMESTAMP NOT NULL,
  revoked_at TIMESTAMP NULL,
  replaced_by_token_id CHAR(36) NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  UNIQUE KEY uq_platform_refresh_token_hash (token_hash),
  KEY idx_platform_refresh_user_status (
    platform_user_id,
    revoked_at,
    expires_at
  )
);

CREATE TABLE IF NOT EXISTS platform_login_attempts (
  id CHAR(36) PRIMARY KEY,
  email VARCHAR(255) NOT NULL,
  platform_user_id CHAR(36) NULL,

  was_successful BOOLEAN NOT NULL,
  failure_reason VARCHAR(255) NULL,

  ip_address VARCHAR(64) NULL,
  user_agent VARCHAR(1000) NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  KEY idx_platform_login_email_time (
    email,
    created_at
  ),

  KEY idx_platform_login_user_time (
    platform_user_id,
    created_at
  )
);

CREATE TABLE IF NOT EXISTS platform_password_reset_tokens (
  id CHAR(36) PRIMARY KEY,
  platform_user_id CHAR(36) NOT NULL,

  token_hash VARCHAR(255) NOT NULL,
  expires_at TIMESTAMP NOT NULL,
  used_at TIMESTAMP NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  UNIQUE KEY uq_platform_password_reset_hash (token_hash),
  KEY idx_platform_password_reset_user (
    platform_user_id,
    expires_at,
    used_at
  )
);

CREATE TABLE IF NOT EXISTS platform_user_invitations (
  id CHAR(36) PRIMARY KEY,
  platform_user_id CHAR(36) NOT NULL,

  invitation_token_hash VARCHAR(255) NOT NULL,
  invited_by CHAR(36) NOT NULL,

  expires_at TIMESTAMP NOT NULL,
  accepted_at TIMESTAMP NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  UNIQUE KEY uq_platform_invitation_hash (
    invitation_token_hash
  ),

  KEY idx_platform_invitation_user (
    platform_user_id,
    expires_at,
    accepted_at
  )
);
