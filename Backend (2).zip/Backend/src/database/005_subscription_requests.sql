CREATE TABLE IF NOT EXISTS subscription_requests (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  user_id CHAR(36) NOT NULL,
  plan_id CHAR(36) NOT NULL,
  status ENUM('pending_payment','payment_submitted','approved','rejected','cancelled')
    NOT NULL DEFAULT 'pending_payment',
  payment_reference VARCHAR(120) NULL,
  payment_proof_url TEXT NULL,
  payment_note VARCHAR(500) NULL,
  reviewed_by CHAR(36) NULL,
  reviewed_at TIMESTAMP NULL,
  rejection_reason VARCHAR(500) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_sub_requests_tenant_user (tenant_id, user_id, created_at),
  KEY idx_sub_requests_tenant_status (tenant_id, status, created_at)
);

CREATE TABLE IF NOT EXISTS subscription_events (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  subscription_request_id CHAR(36) NULL,
  user_subscription_id CHAR(36) NULL,
  user_id CHAR(36) NOT NULL,
  actor_user_id CHAR(36) NULL,
  event_type VARCHAR(80) NOT NULL,
  metadata JSON NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_subscription_events_user (tenant_id, user_id, created_at)
);
