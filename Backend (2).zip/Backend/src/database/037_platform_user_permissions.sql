CREATE TABLE IF NOT EXISTS platform_user_permissions (
  id CHAR(36) PRIMARY KEY,
  platform_user_id CHAR(36) NOT NULL,
  permission_code VARCHAR(180) NOT NULL,
  granted_by CHAR(36) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  UNIQUE KEY uq_platform_user_permission (
    platform_user_id,
    permission_code
  ),

  KEY idx_platform_permission_code (
    permission_code
  ),

  CONSTRAINT fk_platform_permission_user
    FOREIGN KEY (platform_user_id)
    REFERENCES platform_users(id)
    ON DELETE CASCADE,

  CONSTRAINT fk_platform_permission_granted_by
    FOREIGN KEY (granted_by)
    REFERENCES platform_users(id)
    ON DELETE SET NULL
);
