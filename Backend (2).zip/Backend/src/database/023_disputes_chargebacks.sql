CREATE TABLE IF NOT EXISTS dispute_cases (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  user_id CHAR(36) NOT NULL,

  account_id CHAR(36) NOT NULL,
  transaction_id CHAR(36) NULL,

  dispute_reference VARCHAR(180) NOT NULL,
  dispute_type ENUM(
    'card_transaction',
    'bank_transfer',
    'cash_withdrawal',
    'direct_debit',
    'fee',
    'loan',
    'investment',
    'other'
  ) NOT NULL,

  reason_code VARCHAR(120) NOT NULL,
  reason_description VARCHAR(2000) NULL,

  disputed_amount DECIMAL(18,2) NOT NULL,
  currency CHAR(3) NOT NULL,

  status ENUM(
    'submitted',
    'under_review',
    'awaiting_customer',
    'awaiting_merchant',
    'provisional_credit_issued',
    'chargeback_filed',
    'representment_received',
    'pre_arbitration',
    'arbitration',
    'resolved_customer',
    'resolved_merchant',
    'withdrawn',
    'closed'
  ) NOT NULL DEFAULT 'submitted',

  priority ENUM(
    'low',
    'medium',
    'high',
    'urgent'
  ) NOT NULL DEFAULT 'medium',

  assigned_to CHAR(36) NULL,

  provisional_credit_amount DECIMAL(18,2) NULL,
  provisional_credit_journal_id CHAR(36) NULL,
  provisional_credit_reversal_journal_id CHAR(36) NULL,

  final_refund_amount DECIMAL(18,2) NULL,
  final_refund_journal_id CHAR(36) NULL,

  liability_party ENUM(
    'unknown',
    'customer',
    'merchant',
    'bank',
    'network'
  ) NOT NULL DEFAULT 'unknown',

  filed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  acknowledged_at TIMESTAMP NULL,
  due_at TIMESTAMP NULL,
  resolved_at TIMESTAMP NULL,
  closed_at TIMESTAMP NULL,

  resolution_summary VARCHAR(2000) NULL,
  metadata JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_dispute_reference (
    tenant_id,
    dispute_reference
  ),

  KEY idx_dispute_cases_status (
    tenant_id,
    status,
    due_at
  ),

  KEY idx_dispute_cases_customer (
    tenant_id,
    user_id,
    created_at
  ),

  KEY idx_dispute_cases_transaction (
    tenant_id,
    transaction_id
  )
);

CREATE TABLE IF NOT EXISTS dispute_events (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  dispute_case_id CHAR(36) NOT NULL,

  event_type VARCHAR(140) NOT NULL,
  actor_user_id CHAR(36) NULL,
  actor_type ENUM(
    'customer',
    'staff',
    'system',
    'merchant',
    'network'
  ) NOT NULL,

  note VARCHAR(2000) NULL,
  metadata JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  KEY idx_dispute_events_case (
    dispute_case_id,
    created_at
  )
);

CREATE TABLE IF NOT EXISTS dispute_evidence (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  dispute_case_id CHAR(36) NOT NULL,

  evidence_type VARCHAR(120) NOT NULL,
  title VARCHAR(220) NOT NULL,
  description VARCHAR(2000) NULL,

  storage_key VARCHAR(1000) NOT NULL,
  mime_type VARCHAR(180) NULL,
  file_size_bytes BIGINT UNSIGNED NULL,
  checksum_sha256 CHAR(64) NULL,

  submitted_by CHAR(36) NULL,
  submitter_type ENUM(
    'customer',
    'staff',
    'merchant',
    'network'
  ) NOT NULL,

  status ENUM(
    'pending_review',
    'accepted',
    'rejected'
  ) NOT NULL DEFAULT 'pending_review',

  reviewed_by CHAR(36) NULL,
  reviewed_at TIMESTAMP NULL,
  review_note VARCHAR(1000) NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  KEY idx_dispute_evidence_case (
    dispute_case_id,
    created_at
  )
);

CREATE TABLE IF NOT EXISTS chargeback_records (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  dispute_case_id CHAR(36) NOT NULL,

  network VARCHAR(120) NULL,
  chargeback_reference VARCHAR(180) NOT NULL,

  stage ENUM(
    'first_chargeback',
    'representment',
    'pre_arbitration',
    'arbitration',
    'closed'
  ) NOT NULL DEFAULT 'first_chargeback',

  reason_code VARCHAR(120) NOT NULL,
  amount DECIMAL(18,2) NOT NULL,
  currency CHAR(3) NOT NULL,

  filed_at TIMESTAMP NULL,
  response_due_at TIMESTAMP NULL,
  responded_at TIMESTAMP NULL,

  outcome ENUM(
    'pending',
    'accepted',
    'rejected',
    'won',
    'lost',
    'partially_won'
  ) NOT NULL DEFAULT 'pending',

  outcome_amount DECIMAL(18,2) NULL,
  metadata JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_chargeback_reference (
    tenant_id,
    chargeback_reference
  ),

  KEY idx_chargeback_case (
    dispute_case_id,
    stage
  )
);

CREATE TABLE IF NOT EXISTS dispute_refunds (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  dispute_case_id CHAR(36) NOT NULL,

  refund_type ENUM(
    'provisional_credit',
    'final_refund',
    'partial_refund',
    'credit_reversal'
  ) NOT NULL,

  amount DECIMAL(18,2) NOT NULL,
  currency CHAR(3) NOT NULL,

  customer_ledger_account_id CHAR(36) NOT NULL,
  offset_ledger_account_id CHAR(36) NOT NULL,

  idempotency_key VARCHAR(180) NOT NULL,
  journal_id CHAR(36) NULL,

  status ENUM(
    'pending',
    'posted',
    'reversed',
    'failed'
  ) NOT NULL DEFAULT 'pending',

  reason VARCHAR(1000) NULL,
  created_by CHAR(36) NOT NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  posted_at TIMESTAMP NULL,

  UNIQUE KEY uq_dispute_refund_idempotency (
    tenant_id,
    idempotency_key
  )
);

CREATE TABLE IF NOT EXISTS complaint_cases (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  user_id CHAR(36) NOT NULL,

  complaint_reference VARCHAR(180) NOT NULL,
  category VARCHAR(120) NOT NULL,
  subject VARCHAR(220) NOT NULL,
  description MEDIUMTEXT NOT NULL,

  channel ENUM(
    'app',
    'email',
    'phone',
    'branch',
    'social',
    'other'
  ) NOT NULL,

  severity ENUM(
    'low',
    'medium',
    'high',
    'critical'
  ) NOT NULL DEFAULT 'medium',

  status ENUM(
    'submitted',
    'acknowledged',
    'investigating',
    'awaiting_customer',
    'resolved',
    'escalated',
    'closed'
  ) NOT NULL DEFAULT 'submitted',

  assigned_to CHAR(36) NULL,

  acknowledged_at TIMESTAMP NULL,
  due_at TIMESTAMP NULL,
  resolved_at TIMESTAMP NULL,
  closed_at TIMESTAMP NULL,

  resolution VARCHAR(2000) NULL,
  compensation_amount DECIMAL(18,2) NULL,
  compensation_currency CHAR(3) NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_complaint_reference (
    tenant_id,
    complaint_reference
  ),

  KEY idx_complaint_status (
    tenant_id,
    status,
    due_at
  )
);
