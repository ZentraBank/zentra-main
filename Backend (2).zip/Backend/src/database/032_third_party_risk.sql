CREATE TABLE IF NOT EXISTS third_parties (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  third_party_code VARCHAR(120) NOT NULL,
  legal_name VARCHAR(255) NOT NULL,
  trading_name VARCHAR(255) NULL,

  third_party_type ENUM(
    'technology_vendor',
    'cloud_provider',
    'payment_processor',
    'banking_partner',
    'data_provider',
    'professional_services',
    'outsourcer',
    'affiliate',
    'other'
  ) NOT NULL,

  country_code CHAR(2) NULL,
  registration_number VARCHAR(180) NULL,
  tax_identifier VARCHAR(180) NULL,

  primary_contact_name VARCHAR(255) NULL,
  primary_contact_email VARCHAR(255) NULL,
  primary_contact_phone VARCHAR(80) NULL,

  status ENUM(
    'prospective',
    'due_diligence',
    'approved',
    'active',
    'suspended',
    'offboarding',
    'terminated',
    'rejected'
  ) NOT NULL DEFAULT 'prospective',

  criticality ENUM(
    'non_critical',
    'important',
    'critical'
  ) NOT NULL DEFAULT 'non_critical',

  service_owner_user_id CHAR(36) NOT NULL,
  risk_owner_user_id CHAR(36) NULL,

  start_date DATE NULL,
  end_date DATE NULL,

  metadata JSON NULL,

  created_by CHAR(36) NOT NULL,
  approved_by CHAR(36) NULL,
  approved_at TIMESTAMP NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_third_party_code (
    tenant_id,
    third_party_code
  ),

  KEY idx_third_party_status (
    tenant_id,
    status,
    criticality
  )
);

CREATE TABLE IF NOT EXISTS third_party_services (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  third_party_id CHAR(36) NOT NULL,

  service_code VARCHAR(120) NOT NULL,
  service_name VARCHAR(255) NOT NULL,
  description TEXT NULL,

  service_category VARCHAR(180) NOT NULL,

  supports_critical_business_service BOOLEAN NOT NULL DEFAULT FALSE,
  critical_business_service_id CHAR(36) NULL,

  data_access_level ENUM(
    'none',
    'public',
    'internal',
    'confidential',
    'restricted'
  ) NOT NULL DEFAULT 'none',

  personal_data_processed BOOLEAN NOT NULL DEFAULT FALSE,
  payment_data_processed BOOLEAN NOT NULL DEFAULT FALSE,

  service_locations JSON NULL,
  subcontracting_allowed BOOLEAN NOT NULL DEFAULT FALSE,

  status ENUM(
    'planned',
    'active',
    'suspended',
    'terminated'
  ) NOT NULL DEFAULT 'planned',

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_third_party_service (
    tenant_id,
    third_party_id,
    service_code
  )
);

CREATE TABLE IF NOT EXISTS third_party_due_diligence (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  third_party_id CHAR(36) NOT NULL,

  assessment_reference VARCHAR(180) NOT NULL,
  assessment_type ENUM(
    'initial',
    'periodic',
    'event_driven',
    'renewal',
    'exit'
  ) NOT NULL,

  scope JSON NOT NULL,

  inherent_risk_score DECIMAL(7,2) NULL,
  control_effectiveness_score DECIMAL(7,2) NULL,
  residual_risk_score DECIMAL(7,2) NULL,

  risk_rating ENUM(
    'low',
    'medium',
    'high',
    'critical'
  ) NULL,

  status ENUM(
    'draft',
    'in_progress',
    'awaiting_evidence',
    'ready_for_review',
    'approved',
    'rejected',
    'expired'
  ) NOT NULL DEFAULT 'draft',

  assessor_user_id CHAR(36) NOT NULL,
  reviewer_user_id CHAR(36) NULL,

  started_at TIMESTAMP NULL,
  completed_at TIMESTAMP NULL,
  expires_at TIMESTAMP NULL,

  summary TEXT NULL,
  rejection_reason TEXT NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_due_diligence_reference (
    tenant_id,
    assessment_reference
  ),

  KEY idx_due_diligence_status (
    tenant_id,
    third_party_id,
    status
  )
);

CREATE TABLE IF NOT EXISTS third_party_assessment_responses (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  due_diligence_id CHAR(36) NOT NULL,

  section_code VARCHAR(120) NOT NULL,
  question_code VARCHAR(180) NOT NULL,

  response_value JSON NULL,
  score DECIMAL(7,2) NULL,
  weight DECIMAL(7,2) NULL,

  evidence_storage_key VARCHAR(1000) NULL,
  assessor_comment TEXT NULL,

  status ENUM(
    'pending',
    'answered',
    'verified',
    'rejected'
  ) NOT NULL DEFAULT 'pending',

  verified_by CHAR(36) NULL,
  verified_at TIMESTAMP NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_assessment_response (
    due_diligence_id,
    section_code,
    question_code
  )
);

CREATE TABLE IF NOT EXISTS third_party_contracts (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  third_party_id CHAR(36) NOT NULL,

  contract_reference VARCHAR(180) NOT NULL,
  contract_name VARCHAR(255) NOT NULL,
  contract_type ENUM(
    'master_services',
    'statement_of_work',
    'data_processing',
    'outsourcing',
    'licence',
    'support',
    'other'
  ) NOT NULL,

  effective_from DATE NOT NULL,
  effective_to DATE NULL,
  renewal_date DATE NULL,

  auto_renew BOOLEAN NOT NULL DEFAULT FALSE,
  notice_period_days INT UNSIGNED NULL,

  total_contract_value DECIMAL(18,2) NULL,
  currency CHAR(3) NULL,

  governing_law VARCHAR(255) NULL,
  termination_rights TEXT NULL,
  audit_rights TEXT NULL,
  data_return_deletion_terms TEXT NULL,
  business_continuity_requirements TEXT NULL,

  contract_storage_key VARCHAR(1000) NULL,
  contract_hash CHAR(64) NULL,

  status ENUM(
    'draft',
    'active',
    'expired',
    'terminated',
    'superseded'
  ) NOT NULL DEFAULT 'draft',

  owner_user_id CHAR(36) NOT NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_third_party_contract_reference (
    tenant_id,
    contract_reference
  )
);

CREATE TABLE IF NOT EXISTS third_party_slas (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  third_party_service_id CHAR(36) NOT NULL,

  sla_code VARCHAR(120) NOT NULL,
  metric_name VARCHAR(255) NOT NULL,

  metric_type ENUM(
    'availability',
    'latency',
    'recovery_time',
    'recovery_point',
    'support_response',
    'incident_notification',
    'processing_accuracy',
    'other'
  ) NOT NULL,

  target_value DECIMAL(18,4) NOT NULL,
  comparison_operator ENUM(
    'gte',
    'lte',
    'eq'
  ) NOT NULL,

  unit VARCHAR(80) NOT NULL,
  measurement_window VARCHAR(120) NOT NULL,

  breach_severity ENUM(
    'low',
    'medium',
    'high',
    'critical'
  ) NOT NULL DEFAULT 'medium',

  service_credit_terms TEXT NULL,

  status ENUM(
    'active',
    'inactive'
  ) NOT NULL DEFAULT 'active',

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_third_party_sla (
    tenant_id,
    third_party_service_id,
    sla_code
  )
);

CREATE TABLE IF NOT EXISTS third_party_sla_measurements (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  sla_id CHAR(36) NOT NULL,

  measurement_reference VARCHAR(180) NOT NULL,

  period_start TIMESTAMP NOT NULL,
  period_end TIMESTAMP  NULL,

  measured_value DECIMAL(18,4) NOT NULL,
  compliant BOOLEAN NOT NULL,

  breach_minutes INT UNSIGNED NULL,
  evidence_storage_key VARCHAR(1000) NULL,

  recorded_by CHAR(36) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  UNIQUE KEY uq_sla_measurement_reference (
    tenant_id,
    measurement_reference
  ),

  KEY idx_sla_measurement_compliance (
    tenant_id,
    sla_id,
    compliant,
    period_end
  )
);

CREATE TABLE IF NOT EXISTS third_party_risk_issues (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  third_party_id CHAR(36) NOT NULL,
  due_diligence_id CHAR(36) NULL,

  issue_reference VARCHAR(180) NOT NULL,
  title VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,

  category VARCHAR(180) NOT NULL,
  severity ENUM(
    'low',
    'medium',
    'high',
    'critical'
  ) NOT NULL,

  status ENUM(
    'open',
    'accepted',
    'mitigating',
    'remediated',
    'closed',
    'overdue'
  ) NOT NULL DEFAULT 'open',

  remediation_plan TEXT NULL,
  owner_user_id CHAR(36) NOT NULL,

  due_at TIMESTAMP NULL,
  completed_at TIMESTAMP NULL,

  risk_acceptance_reference VARCHAR(255) NULL,
  evidence_storage_key VARCHAR(1000) NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_third_party_issue_reference (
    tenant_id,
    issue_reference
  )
);

CREATE TABLE IF NOT EXISTS third_party_concentration_exposures (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  third_party_id CHAR(36) NOT NULL,

  exposure_type ENUM(
    'service',
    'geography',
    'cloud',
    'payment_rail',
    'data',
    'subcontractor',
    'financial',
    'other'
  ) NOT NULL,

  exposure_reference VARCHAR(255) NOT NULL,
  exposure_percentage DECIMAL(7,4) NULL,
  exposure_amount DECIMAL(18,2) NULL,
  currency CHAR(3) NULL,

  concentration_rating ENUM(
    'low',
    'medium',
    'high',
    'critical'
  ) NOT NULL,

  mitigation_strategy TEXT NULL,

  measured_at TIMESTAMP NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  KEY idx_concentration_exposure (
    tenant_id,
    exposure_type,
    concentration_rating
  )
);

CREATE TABLE IF NOT EXISTS third_party_exit_plans (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  third_party_id CHAR(36) NOT NULL,

  plan_reference VARCHAR(180) NOT NULL,
  plan_name VARCHAR(255) NOT NULL,

  exit_triggers JSON NOT NULL,
  replacement_strategy TEXT NOT NULL,
  transition_steps JSON NOT NULL,

  data_return_strategy TEXT NULL,
  data_deletion_verification TEXT NULL,
  continuity_arrangements TEXT NULL,

  estimated_exit_days INT UNSIGNED NULL,
  estimated_exit_cost DECIMAL(18,2) NULL,
  currency CHAR(3) NULL,

  last_tested_at TIMESTAMP NULL,
  next_test_due_at TIMESTAMP NULL,

  status ENUM(
    'draft',
    'active',
    'tested',
    'invoked',
    'completed',
    'retired'
  ) NOT NULL DEFAULT 'draft',

  created_by CHAR(36) NOT NULL,
  approved_by CHAR(36) NULL,
  approved_at TIMESTAMP NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_third_party_exit_plan (
    tenant_id,
    plan_reference
  )
);
