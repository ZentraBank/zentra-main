CREATE TABLE IF NOT EXISTS fee_definitions (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  code VARCHAR(120) NOT NULL,
  name VARCHAR(180) NOT NULL,
  description VARCHAR(1000) NULL,

  event_type VARCHAR(120) NOT NULL,

  calculation_type ENUM(
    'fixed',
    'percentage',
    'tiered'
  ) NOT NULL,

  fixed_amount DECIMAL(18,2) NULL,
  percentage_rate DECIMAL(12,6) NULL,

  minimum_fee DECIMAL(18,2) NULL,
  maximum_fee DECIMAL(18,2) NULL,

  currency CHAR(3) NULL,

  tiers JSON NULL,

  revenue_ledger_account_id CHAR(36) NOT NULL,
  tax_ledger_account_id CHAR(36) NULL,
  tax_rate DECIMAL(12,6) NULL,

  status ENUM(
    'active',
    'inactive',
    'draft'
  ) NOT NULL DEFAULT 'active',

  priority INT NOT NULL DEFAULT 100,

  created_by CHAR(36) NOT NULL,
  updated_by CHAR(36) NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_fee_definition_code (
    tenant_id,
    code
  ),

  KEY idx_fee_definitions_event (
    tenant_id,
    event_type,
    status,
    priority
  )
);

CREATE TABLE IF NOT EXISTS fee_assessments (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  fee_definition_id CHAR(36) NOT NULL,

  source_type VARCHAR(120) NOT NULL,
  source_id CHAR(36) NOT NULL,

  account_id CHAR(36) NOT NULL,
  customer_ledger_account_id CHAR(36) NOT NULL,

  idempotency_key VARCHAR(160) NOT NULL,
  reference VARCHAR(160) NOT NULL,

  base_amount DECIMAL(18,2) NOT NULL DEFAULT 0,
  fee_amount DECIMAL(18,2) NOT NULL DEFAULT 0,
  tax_amount DECIMAL(18,2) NOT NULL DEFAULT 0,
  total_amount DECIMAL(18,2) NOT NULL DEFAULT 0,

  currency CHAR(3) NOT NULL,

  status ENUM(
    'pending',
    'posted',
    'waived',
    'reversed',
    'failed'
  ) NOT NULL DEFAULT 'pending',

  ledger_journal_id CHAR(36) NULL,
  reversal_journal_id CHAR(36) NULL,

  waived_by CHAR(36) NULL,
  waiver_reason VARCHAR(1000) NULL,

  metadata JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  posted_at TIMESTAMP NULL,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_fee_assessment_idempotency (
    tenant_id,
    idempotency_key
  ),

  UNIQUE KEY uq_fee_assessment_reference (
    tenant_id,
    reference
  ),

  KEY idx_fee_assessments_account (
    tenant_id,
    account_id,
    status,
    created_at
  )
);

CREATE TABLE IF NOT EXISTS interest_products (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  code VARCHAR(120) NOT NULL,
  name VARCHAR(180) NOT NULL,
  description VARCHAR(1000) NULL,

  product_type ENUM(
    'deposit',
    'loan',
    'investment'
  ) NOT NULL,

  annual_rate DECIMAL(12,6) NOT NULL,

  calculation_basis ENUM(
    'daily_balance',
    'average_daily_balance',
    'simple',
    'compound'
  ) NOT NULL,

  day_count_convention ENUM(
    'actual_365',
    'actual_360',
    '30_360'
  ) NOT NULL DEFAULT 'actual_365',

  posting_frequency ENUM(
    'daily',
    'weekly',
    'monthly',
    'quarterly',
    'annually',
    'maturity'
  ) NOT NULL,

  minimum_balance DECIMAL(18,2) NULL,
  maximum_balance DECIMAL(18,2) NULL,

  currency CHAR(3) NOT NULL,

  expense_ledger_account_id CHAR(36) NULL,
  income_ledger_account_id CHAR(36) NULL,
  payable_ledger_account_id CHAR(36) NULL,
  receivable_ledger_account_id CHAR(36) NULL,

  status ENUM(
    'active',
    'inactive',
    'draft'
  ) NOT NULL DEFAULT 'active',

  created_by CHAR(36) NOT NULL,
  updated_by CHAR(36) NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_interest_product_code (
    tenant_id,
    code
  )
);

CREATE TABLE IF NOT EXISTS interest_accruals (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  interest_product_id CHAR(36) NOT NULL,

  source_type VARCHAR(120) NOT NULL,
  source_id CHAR(36) NOT NULL,

  account_id CHAR(36) NULL,
  customer_ledger_account_id CHAR(36) NULL,

  accrual_date DATE NOT NULL,
  period_start DATE NOT NULL,
  period_end DATE NOT NULL,

  principal_amount DECIMAL(18,2) NOT NULL,
  annual_rate DECIMAL(12,6) NOT NULL,
  day_fraction DECIMAL(18,10) NOT NULL,

  accrued_amount DECIMAL(18,2) NOT NULL,
  currency CHAR(3) NOT NULL,

  status ENUM(
    'accrued',
    'posted',
    'reversed',
    'failed'
  ) NOT NULL DEFAULT 'accrued',

  ledger_journal_id CHAR(36) NULL,
  reversal_journal_id CHAR(36) NULL,

  idempotency_key VARCHAR(160) NOT NULL,

  metadata JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  posted_at TIMESTAMP NULL,

  UNIQUE KEY uq_interest_accrual_idempotency (
    tenant_id,
    idempotency_key
  ),

  KEY idx_interest_accrual_source (
    tenant_id,
    source_type,
    source_id,
    accrual_date
  )
);

CREATE TABLE IF NOT EXISTS treasury_positions (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  currency CHAR(3) NOT NULL,
  position_date DATE NOT NULL,

  total_customer_liabilities DECIMAL(18,2) NOT NULL DEFAULT 0,
  total_cash_assets DECIMAL(18,2) NOT NULL DEFAULT 0,
  total_loan_assets DECIMAL(18,2) NOT NULL DEFAULT 0,
  total_investment_liabilities DECIMAL(18,2) NOT NULL DEFAULT 0,

  net_liquidity_position DECIMAL(18,2) NOT NULL DEFAULT 0,

  metadata JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  UNIQUE KEY uq_treasury_position (
    tenant_id,
    currency,
    position_date
  )
);
