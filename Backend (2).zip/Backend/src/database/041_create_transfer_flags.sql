CREATE TABLE transfer_flags (
  id CHAR(36) NOT NULL PRIMARY KEY,

  tenant_id CHAR(36) NOT NULL,
  transfer_id CHAR(36) NOT NULL,

  reason VARCHAR(255) NOT NULL,
  notes TEXT NULL,

  status ENUM(
    'under_review',
    'cleared',
    'action_required'
  ) NOT NULL DEFAULT 'under_review',

  flagged_by CHAR(36) NOT NULL,
  flagged_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

  reviewed_by CHAR(36) NULL,
  reviewed_at DATETIME NULL,
  review_notes TEXT NULL,

  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  CONSTRAINT fk_transfer_flags_tenant
    FOREIGN KEY (tenant_id)
    REFERENCES tenants(id),

  CONSTRAINT fk_transfer_flags_transfer
    FOREIGN KEY (transfer_id)
    REFERENCES transfers(id),

  CONSTRAINT fk_transfer_flags_flagged_by
    FOREIGN KEY (flagged_by)
    REFERENCES users(id),

  CONSTRAINT fk_transfer_flags_reviewed_by
    FOREIGN KEY (reviewed_by)
    REFERENCES users(id),

  INDEX idx_transfer_flags_tenant (
    tenant_id
  ),

  INDEX idx_transfer_flags_transfer (
    transfer_id
  ),

  INDEX idx_transfer_flags_status (
    tenant_id,
    status
  )
);