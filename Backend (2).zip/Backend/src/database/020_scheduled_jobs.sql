CREATE TABLE IF NOT EXISTS scheduled_job_definitions (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NULL,

  code VARCHAR(140) NOT NULL,
  name VARCHAR(180) NOT NULL,
  description VARCHAR(1000) NULL,

  queue_name VARCHAR(120) NOT NULL,
  job_name VARCHAR(140) NOT NULL,

  schedule_type ENUM(
    'cron',
    'interval',
    'manual'
  ) NOT NULL,

  cron_expression VARCHAR(120) NULL,
  interval_seconds INT UNSIGNED NULL,
  timezone VARCHAR(120) NOT NULL DEFAULT 'UTC',

  payload JSON NULL,

  concurrency_limit INT UNSIGNED NOT NULL DEFAULT 1,
  retry_attempts INT UNSIGNED NOT NULL DEFAULT 3,
  retry_backoff_ms INT UNSIGNED NOT NULL DEFAULT 5000,
  timeout_ms INT UNSIGNED NOT NULL DEFAULT 300000,

  status ENUM(
    'active',
    'paused',
    'disabled'
  ) NOT NULL DEFAULT 'active',

  last_enqueued_at TIMESTAMP NULL,
  next_run_at TIMESTAMP NULL,

  created_by CHAR(36) NULL,
  updated_by CHAR(36) NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_scheduled_job_definition (
    tenant_id,
    code
  ),

  KEY idx_scheduled_job_status (
    status,
    next_run_at
  )
);

CREATE TABLE IF NOT EXISTS scheduled_job_runs (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NULL,
  job_definition_id CHAR(36) NULL,

  queue_job_id VARCHAR(160) NULL,
  job_code VARCHAR(140) NOT NULL,
  job_name VARCHAR(140) NOT NULL,

  trigger_type ENUM(
    'schedule',
    'manual',
    'retry',
    'system'
  ) NOT NULL,

  status ENUM(
    'queued',
    'processing',
    'completed',
    'failed',
    'cancelled',
    'dead_letter'
  ) NOT NULL DEFAULT 'queued',

  attempt_number INT UNSIGNED NOT NULL DEFAULT 1,

  payload JSON NULL,
  result JSON NULL,
  error_message VARCHAR(2000) NULL,
  error_stack MEDIUMTEXT NULL,

  queued_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  started_at TIMESTAMP NULL,
  completed_at TIMESTAMP NULL,
  duration_ms INT UNSIGNED NULL,

  triggered_by CHAR(36) NULL,
  correlation_id VARCHAR(160) NULL,

  KEY idx_scheduled_job_runs_status (
    status,
    queued_at
  ),

  KEY idx_scheduled_job_runs_definition (
    job_definition_id,
    queued_at
  ),

  KEY idx_scheduled_job_runs_tenant (
    tenant_id,
    job_code,
    queued_at
  )
);

CREATE TABLE IF NOT EXISTS scheduled_job_locks (
  lock_key VARCHAR(220) PRIMARY KEY,
  owner_id VARCHAR(160) NOT NULL,
  acquired_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expires_at TIMESTAMP NOT NULL,

  KEY idx_scheduled_job_locks_expiry (
    expires_at
  )
);

CREATE TABLE IF NOT EXISTS scheduled_job_dead_letters (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NULL,
  scheduled_job_run_id CHAR(36) NOT NULL,

  job_code VARCHAR(140) NOT NULL,
  payload JSON NULL,

  failure_reason VARCHAR(2000) NOT NULL,
  failure_stack MEDIUMTEXT NULL,

  retry_count INT UNSIGNED NOT NULL DEFAULT 0,
  status ENUM(
    'pending',
    'requeued',
    'discarded'
  ) NOT NULL DEFAULT 'pending',

  requeued_by CHAR(36) NULL,
  requeued_at TIMESTAMP NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  KEY idx_dead_letter_status (
    status,
    created_at
  )
);
