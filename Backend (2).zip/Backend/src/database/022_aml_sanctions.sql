CREATE TABLE IF NOT EXISTS compliance_watchlists (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NULL,

  name VARCHAR(180) NOT NULL,
  source VARCHAR(180) NOT NULL,
  jurisdiction VARCHAR(120) NULL,

  list_type ENUM(
    'sanctions',
    'pep',
    'adverse_media',
    'internal'
  ) NOT NULL,

  version VARCHAR(120) NULL,
  effective_at TIMESTAMP NULL,

  status ENUM(
    'active',
    'inactive',
    'archived'
  ) NOT NULL DEFAULT 'active',

  metadata JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  KEY idx_compliance_watchlists_type (
    list_type,
    status
  )
);

CREATE TABLE IF NOT EXISTS compliance_watchlist_entries (
  id CHAR(36) PRIMARY KEY,
  watchlist_id CHAR(36) NOT NULL,

  entity_type ENUM(
    'person',
    'organisation',
    'vessel',
    'country',
    'other'
  ) NOT NULL,

  primary_name VARCHAR(255) NOT NULL,
  aliases JSON NULL,

  date_of_birth DATE NULL,
  countries JSON NULL,
  identification_numbers JSON NULL,

  risk_categories JSON NULL,
  source_reference VARCHAR(255) NULL,

  status ENUM(
    'active',
    'inactive',
    'removed'
  ) NOT NULL DEFAULT 'active',

  raw_data JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  KEY idx_watchlist_entry_name (
    primary_name
  ),

  KEY idx_watchlist_entry_status (
    watchlist_id,
    status
  )
);

CREATE TABLE IF NOT EXISTS customer_risk_profiles (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  user_id CHAR(36) NOT NULL,

  risk_score INT NOT NULL DEFAULT 0,

  risk_level ENUM(
    'low',
    'medium',
    'high',
    'prohibited'
  ) NOT NULL DEFAULT 'low',

  customer_type ENUM(
    'individual',
    'business'
  ) NOT NULL DEFAULT 'individual',

  occupation VARCHAR(180) NULL,
  industry VARCHAR(180) NULL,
  expected_monthly_volume DECIMAL(18,2) NULL,
  expected_monthly_count INT UNSIGNED NULL,

  country_of_residence CHAR(2) NULL,
  nationality CHAR(2) NULL,

  pep_status ENUM(
    'unknown',
    'not_pep',
    'pep',
    'relative_or_close_associate'
  ) NOT NULL DEFAULT 'unknown',

  sanctions_status ENUM(
    'not_screened',
    'clear',
    'potential_match',
    'confirmed_match'
  ) NOT NULL DEFAULT 'not_screened',

  source_of_funds VARCHAR(1000) NULL,
  source_of_wealth VARCHAR(1000) NULL,

  last_reviewed_at TIMESTAMP NULL,
  next_review_at TIMESTAMP NULL,
  reviewed_by CHAR(36) NULL,

  metadata JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_customer_risk_profile (
    tenant_id,
    user_id
  ),

  KEY idx_customer_risk_level (
    tenant_id,
    risk_level,
    next_review_at
  )
);

CREATE TABLE IF NOT EXISTS compliance_screenings (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  user_id CHAR(36) NULL,

  screening_type ENUM(
    'customer_onboarding',
    'periodic_review',
    'transaction_party',
    'manual'
  ) NOT NULL,

  subject_name VARCHAR(255) NOT NULL,
  date_of_birth DATE NULL,
  country_code CHAR(2) NULL,
  identification_number VARCHAR(255) NULL,

  idempotency_key VARCHAR(180) NOT NULL,

  status ENUM(
    'clear',
    'potential_match',
    'confirmed_match',
    'error'
  ) NOT NULL,

  highest_match_score DECIMAL(7,4) NULL,
  match_count INT UNSIGNED NOT NULL DEFAULT 0,

  screened_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  screened_by CHAR(36) NULL,

  metadata JSON NULL,

  UNIQUE KEY uq_compliance_screening_idempotency (
    tenant_id,
    idempotency_key
  ),

  KEY idx_compliance_screenings_user (
    tenant_id,
    user_id,
    screened_at
  )
);

CREATE TABLE IF NOT EXISTS compliance_screening_matches (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  screening_id CHAR(36) NOT NULL,
  watchlist_entry_id CHAR(36) NOT NULL,

  name_match_score DECIMAL(7,4) NOT NULL,
  date_of_birth_match BOOLEAN NULL,
  country_match BOOLEAN NULL,
  identification_match BOOLEAN NULL,

  overall_score DECIMAL(7,4) NOT NULL,

  disposition ENUM(
    'unreviewed',
    'false_positive',
    'possible_match',
    'confirmed_match'
  ) NOT NULL DEFAULT 'unreviewed',

  reviewed_by CHAR(36) NULL,
  review_note VARCHAR(2000) NULL,
  reviewed_at TIMESTAMP NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  KEY idx_screening_matches_screening (
    screening_id,
    overall_score
  )
);

CREATE TABLE IF NOT EXISTS transaction_monitoring_rules (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  code VARCHAR(140) NOT NULL,
  name VARCHAR(180) NOT NULL,
  description VARCHAR(1000) NULL,

  event_type VARCHAR(140) NOT NULL,

  rule_type ENUM(
    'amount_threshold',
    'velocity',
    'structuring',
    'country_risk',
    'customer_profile_deviation',
    'rapid_movement',
    'manual'
  ) NOT NULL,

  configuration JSON NOT NULL,

  severity ENUM(
    'low',
    'medium',
    'high',
    'critical'
  ) NOT NULL,

  score INT NOT NULL DEFAULT 0,
  priority INT NOT NULL DEFAULT 100,

  status ENUM(
    'active',
    'inactive',
    'draft'
  ) NOT NULL DEFAULT 'active',

  created_by CHAR(36) NOT NULL,
  updated_by CHAR(36) NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_tm_rule_code (
    tenant_id,
    code
  ),

  KEY idx_tm_rules_event (
    tenant_id,
    event_type,
    status,
    priority
  )
);

CREATE TABLE IF NOT EXISTS compliance_alerts (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  user_id CHAR(36) NULL,

  source_type VARCHAR(120) NOT NULL,
  source_id CHAR(36) NULL,

  alert_reference VARCHAR(180) NOT NULL,
  alert_type ENUM(
    'sanctions_match',
    'pep_match',
    'transaction_monitoring',
    'manual'
  ) NOT NULL,

  severity ENUM(
    'low',
    'medium',
    'high',
    'critical'
  ) NOT NULL,

  score INT NOT NULL DEFAULT 0,

  title VARCHAR(220) NOT NULL,
  description VARCHAR(2000) NULL,

  matched_rules JSON NULL,
  evidence JSON NULL,

  status ENUM(
    'open',
    'investigating',
    'escalated',
    'closed_false_positive',
    'closed_no_action',
    'reported'
  ) NOT NULL DEFAULT 'open',

  assigned_to CHAR(36) NULL,
  resolution_note VARCHAR(2000) NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_compliance_alert_reference (
    tenant_id,
    alert_reference
  ),

  KEY idx_compliance_alerts_status (
    tenant_id,
    status,
    severity,
    created_at
  )
);

CREATE TABLE IF NOT EXISTS compliance_cases (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  user_id CHAR(36) NULL,

  case_reference VARCHAR(180) NOT NULL,
  title VARCHAR(220) NOT NULL,
  description VARCHAR(2000) NULL,

  priority ENUM(
    'low',
    'medium',
    'high',
    'urgent'
  ) NOT NULL DEFAULT 'medium',

  status ENUM(
    'open',
    'investigating',
    'awaiting_information',
    'escalated',
    'closed',
    'reported'
  ) NOT NULL DEFAULT 'open',

  assigned_to CHAR(36) NULL,

  decision ENUM(
    'pending',
    'no_action',
    'enhanced_due_diligence',
    'restrict_account',
    'exit_relationship',
    'file_report'
  ) NOT NULL DEFAULT 'pending',

  decision_reason VARCHAR(2000) NULL,

  created_by CHAR(36) NOT NULL,
  closed_by CHAR(36) NULL,
  closed_at TIMESTAMP NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_compliance_case_reference (
    tenant_id,
    case_reference
  )
);

CREATE TABLE IF NOT EXISTS compliance_case_alerts (
  compliance_case_id CHAR(36) NOT NULL,
  compliance_alert_id CHAR(36) NOT NULL,

  linked_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  linked_by CHAR(36) NOT NULL,

  PRIMARY KEY (
    compliance_case_id,
    compliance_alert_id
  )
);

CREATE TABLE IF NOT EXISTS suspicious_activity_reports (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  compliance_case_id CHAR(36) NOT NULL,

  report_reference VARCHAR(180) NOT NULL,

  jurisdiction VARCHAR(120) NOT NULL,
  report_type VARCHAR(120) NOT NULL,

  status ENUM(
    'draft',
    'approved',
    'submitted',
    'acknowledged',
    'rejected'
  ) NOT NULL DEFAULT 'draft',

  narrative MEDIUMTEXT NOT NULL,
  subject_details JSON NOT NULL,
  transaction_summary JSON NULL,
  supporting_evidence JSON NULL,

  prepared_by CHAR(36) NOT NULL,
  approved_by CHAR(36) NULL,
  submitted_by CHAR(36) NULL,

  submitted_at TIMESTAMP NULL,
  acknowledgement_reference VARCHAR(255) NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_sar_reference (
    tenant_id,
    report_reference
  )
);
