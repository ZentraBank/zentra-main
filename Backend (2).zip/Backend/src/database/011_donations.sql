CREATE TABLE IF NOT EXISTS donors (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  created_by CHAR(36) NOT NULL,

  full_name VARCHAR(160) NOT NULL,
  email VARCHAR(190) NULL,
  phone_number VARCHAR(40) NULL,
  profile_image_url VARCHAR(1000) NULL,

  address VARCHAR(500) NULL,
  country VARCHAR(100) NULL,

  status ENUM(
    'active',
    'inactive',
    'blocked'
  ) NOT NULL DEFAULT 'active',

  metadata JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  KEY idx_donors_tenant_created (
    tenant_id,
    created_at
  ),

  KEY idx_donors_tenant_status (
    tenant_id,
    status
  )
);

CREATE TABLE IF NOT EXISTS donation_requests (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  donor_id CHAR(36) NOT NULL,
  beneficiary_user_id CHAR(36) NOT NULL,
  account_id CHAR(36) NOT NULL,

  amount DECIMAL(18,2) NOT NULL,
  currency CHAR(3) NOT NULL,
  purpose VARCHAR(500) NULL,

  status ENUM(
    'pending',
    'approved',
    'rejected',
    'cancelled',
    'funded',
    'redeemed'
  ) NOT NULL DEFAULT 'pending',

  approved_by CHAR(36) NULL,
  approved_at TIMESTAMP NULL,
  rejected_by CHAR(36) NULL,
  rejected_at TIMESTAMP NULL,
  rejection_reason VARCHAR(1000) NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  KEY idx_donation_requests_tenant_status (
    tenant_id,
    status,
    created_at
  ),

  KEY idx_donation_requests_user (
    tenant_id,
    beneficiary_user_id,
    created_at
  )
);

CREATE TABLE IF NOT EXISTS donation_redemptions (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  donation_request_id CHAR(36) NOT NULL,
  user_id CHAR(36) NOT NULL,

  amount DECIMAL(18,2) NOT NULL,
  currency CHAR(3) NOT NULL,

  otp_hash VARCHAR(255) NULL,
  otp_expires_at TIMESTAMP NULL,
  otp_attempts INT UNSIGNED NOT NULL DEFAULT 0,
  otp_verified_at TIMESTAMP NULL,

  status ENUM(
    'pending_otp',
    'approved',
    'rejected',
    'completed',
    'expired'
  ) NOT NULL DEFAULT 'pending_otp',

  approved_by CHAR(36) NULL,
  approved_at TIMESTAMP NULL,
  rejected_by CHAR(36) NULL,
  rejected_at TIMESTAMP NULL,
  rejection_reason VARCHAR(1000) NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  KEY idx_donation_redemptions_request (
    donation_request_id,
    created_at
  ),

  KEY idx_donation_redemptions_status (
    tenant_id,
    status,
    created_at
  )
);

CREATE TABLE IF NOT EXISTS donation_events (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  donation_request_id CHAR(36) NULL,
  redemption_id CHAR(36) NULL,
  actor_user_id CHAR(36) NULL,
  event_type VARCHAR(100) NOT NULL,
  metadata JSON NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  KEY idx_donation_events_request (
    donation_request_id,
    created_at
  )
);
