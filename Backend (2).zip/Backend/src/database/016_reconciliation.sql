CREATE TABLE IF NOT EXISTS reconciliation_runs (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  run_type ENUM(
    'ledger_vs_accounts',
    'external_statement'
  ) NOT NULL,

  status ENUM(
    'pending',
    'processing',
    'completed',
    'failed'
  ) NOT NULL DEFAULT 'pending',

  currency CHAR(3) NULL,
  started_by CHAR(36) NOT NULL,

  started_at TIMESTAMP NULL,
  completed_at TIMESTAMP NULL,

  total_records INT UNSIGNED NOT NULL DEFAULT 0,
  matched_records INT UNSIGNED NOT NULL DEFAULT 0,
  mismatched_records INT UNSIGNED NOT NULL DEFAULT 0,

  failure_reason VARCHAR(1000) NULL,
  metadata JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  KEY idx_reconciliation_runs_tenant (
    tenant_id,
    status,
    created_at
  )
);

CREATE TABLE IF NOT EXISTS reconciliation_items (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  reconciliation_run_id CHAR(36) NOT NULL,

  source_type ENUM(
    'account',
    'ledger_account',
    'external_statement'
  ) NOT NULL,

  source_id VARCHAR(160) NOT NULL,
  reference VARCHAR(160) NULL,
  currency CHAR(3) NOT NULL,

  internal_amount DECIMAL(18,2) NOT NULL DEFAULT 0,
  external_amount DECIMAL(18,2) NOT NULL DEFAULT 0,
  difference_amount DECIMAL(18,2) NOT NULL DEFAULT 0,

  status ENUM(
    'matched',
    'mismatched',
    'investigating',
    'resolved',
    'ignored'
  ) NOT NULL,

  resolution_note VARCHAR(1000) NULL,
  resolved_by CHAR(36) NULL,
  resolved_at TIMESTAMP NULL,

  metadata JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  KEY idx_reconciliation_items_run (
    reconciliation_run_id,
    status
  ),

  KEY idx_reconciliation_items_source (
    tenant_id,
    source_type,
    source_id
  )
);

CREATE TABLE IF NOT EXISTS external_statement_imports (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  provider_name VARCHAR(160) NOT NULL,
  statement_reference VARCHAR(160) NOT NULL,
  currency CHAR(3) NOT NULL,

  status ENUM(
    'uploaded',
    'parsed',
    'reconciled',
    'failed'
  ) NOT NULL DEFAULT 'uploaded',

  row_count INT UNSIGNED NOT NULL DEFAULT 0,
  imported_by CHAR(36) NOT NULL,

  metadata JSON NULL,
  failure_reason VARCHAR(1000) NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_statement_reference (
    tenant_id,
    statement_reference
  )
);

CREATE TABLE IF NOT EXISTS external_statement_entries (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  import_id CHAR(36) NOT NULL,

  transaction_date DATE NOT NULL,
  reference VARCHAR(160) NOT NULL,
  description VARCHAR(500) NULL,

  amount DECIMAL(18,2) NOT NULL,
  direction ENUM(
    'debit',
    'credit'
  ) NOT NULL,

  currency CHAR(3) NOT NULL,
  running_balance DECIMAL(18,2) NULL,

  matched_journal_id CHAR(36) NULL,
  reconciliation_status ENUM(
    'unmatched',
    'matched',
    'mismatched',
    'ignored'
  ) NOT NULL DEFAULT 'unmatched',

  metadata JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  KEY idx_statement_entries_import (
    import_id,
    reconciliation_status
  ),

  KEY idx_statement_entries_reference (
    tenant_id,
    reference
  )
);
