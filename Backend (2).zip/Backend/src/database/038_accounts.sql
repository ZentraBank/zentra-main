CREATE TABLE IF NOT EXISTS accounts (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  user_id CHAR(36) NOT NULL,

  account_number VARCHAR(30) NOT NULL,
  account_name VARCHAR(160) NOT NULL,
  account_type ENUM(
    'wallet',
    'savings',
    'current',
    'investment'
  ) NOT NULL DEFAULT 'wallet',

  currency CHAR(3) NOT NULL DEFAULT 'USD',
  balance DECIMAL(18,2) NOT NULL DEFAULT 0.00,

  status ENUM(
    'active',
    'inactive',
    'suspended',
    'frozen',
    'closed'
  ) NOT NULL DEFAULT 'active',

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_accounts_number (
    tenant_id,
    account_number
  ),

  KEY idx_accounts_tenant_user (
    tenant_id,
    user_id
  ),

  KEY idx_accounts_tenant_status (
    tenant_id,
    status
  ),

  CONSTRAINT fk_accounts_tenant
    FOREIGN KEY (tenant_id)
    REFERENCES tenants(id)
    ON DELETE CASCADE,

  CONSTRAINT fk_accounts_user
    FOREIGN KEY (user_id)
    REFERENCES users(id)
    ON DELETE CASCADE
);