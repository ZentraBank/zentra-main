CREATE TABLE IF NOT EXISTS approval_policies (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  code VARCHAR(120) NOT NULL,
  name VARCHAR(180) NOT NULL,
  description VARCHAR(1000) NULL,

  action_type VARCHAR(120) NOT NULL,

  minimum_amount DECIMAL(18,2) NULL,
  maximum_amount DECIMAL(18,2) NULL,
  currency CHAR(3) NULL,

  required_approvals INT UNSIGNED NOT NULL DEFAULT 1,

  require_distinct_roles BOOLEAN NOT NULL DEFAULT FALSE,
  prohibit_self_approval BOOLEAN NOT NULL DEFAULT TRUE,

  allowed_role_ids JSON NULL,
  allowed_permission_codes JSON NULL,

  expires_after_minutes INT UNSIGNED NULL,

  status ENUM(
    'active',
    'inactive',
    'draft'
  ) NOT NULL DEFAULT 'active',

  priority INT NOT NULL DEFAULT 100,

  created_by CHAR(36) NOT NULL,
  updated_by CHAR(36) NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_approval_policy_code (
    tenant_id,
    code
  ),

  KEY idx_approval_policy_action (
    tenant_id,
    action_type,
    status,
    priority
  )
);

CREATE TABLE IF NOT EXISTS approval_requests (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  policy_id CHAR(36) NOT NULL,
  action_type VARCHAR(120) NOT NULL,

  source_type VARCHAR(120) NOT NULL,
  source_id CHAR(36) NOT NULL,

  request_reference VARCHAR(160) NOT NULL,
  idempotency_key VARCHAR(160) NOT NULL,

  amount DECIMAL(18,2) NULL,
  currency CHAR(3) NULL,

  requested_by CHAR(36) NOT NULL,

  required_approvals INT UNSIGNED NOT NULL DEFAULT 1,
  approval_count INT UNSIGNED NOT NULL DEFAULT 0,
  rejection_count INT UNSIGNED NOT NULL DEFAULT 0,

  status ENUM(
    'pending',
    'approved',
    'rejected',
    'cancelled',
    'expired'
  ) NOT NULL DEFAULT 'pending',

  expires_at TIMESTAMP NULL,
  approved_at TIMESTAMP NULL,
  rejected_at TIMESTAMP NULL,
  cancelled_at TIMESTAMP NULL,

  payload JSON NULL,
  metadata JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_approval_request_reference (
    tenant_id,
    request_reference
  ),

  UNIQUE KEY uq_approval_request_idempotency (
    tenant_id,
    idempotency_key
  ),

  KEY idx_approval_requests_status (
    tenant_id,
    status,
    created_at
  ),

  KEY idx_approval_requests_source (
    tenant_id,
    source_type,
    source_id
  )
);

CREATE TABLE IF NOT EXISTS approval_decisions (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  approval_request_id CHAR(36) NOT NULL,

  decided_by CHAR(36) NOT NULL,
  decision ENUM(
    'approved',
    'rejected'
  ) NOT NULL,

  role_id CHAR(36) NULL,
  comment VARCHAR(1000) NULL,

  metadata JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  UNIQUE KEY uq_approval_decision_actor (
    approval_request_id,
    decided_by
  ),

  KEY idx_approval_decisions_request (
    approval_request_id,
    created_at
  )
);

CREATE TABLE IF NOT EXISTS approval_request_events (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  approval_request_id CHAR(36) NOT NULL,

  event_type VARCHAR(120) NOT NULL,
  actor_user_id CHAR(36) NULL,
  note VARCHAR(1000) NULL,
  metadata JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  KEY idx_approval_request_events_request (
    approval_request_id,
    created_at
  )
);
