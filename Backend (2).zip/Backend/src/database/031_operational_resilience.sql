CREATE TABLE IF NOT EXISTS critical_business_services (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  service_code VARCHAR(120) NOT NULL,
  service_name VARCHAR(255) NOT NULL,
  description TEXT NULL,

  service_owner_user_id CHAR(36) NOT NULL,
  executive_owner_user_id CHAR(36) NULL,

  criticality ENUM(
    'low',
    'medium',
    'high',
    'critical'
  ) NOT NULL,

  customer_impact_description TEXT NULL,
  regulatory_impact_description TEXT NULL,

  impact_tolerance_minutes INT UNSIGNED NOT NULL,
  recovery_time_objective_minutes INT UNSIGNED NOT NULL,
  recovery_point_objective_minutes INT UNSIGNED NOT NULL,

  minimum_service_level_percentage DECIMAL(5,2) NULL,

  status ENUM(
    'draft',
    'active',
    'suspended',
    'retired'
  ) NOT NULL DEFAULT 'draft',

  last_reviewed_at TIMESTAMP NULL,
  next_review_due_at TIMESTAMP NULL,

  created_by CHAR(36) NOT NULL,
  approved_by CHAR(36) NULL,
  approved_at TIMESTAMP NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_critical_service_code (
    tenant_id,
    service_code
  )
);

CREATE TABLE IF NOT EXISTS service_dependencies (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  critical_business_service_id CHAR(36) NOT NULL,

  dependency_type ENUM(
    'application',
    'database',
    'infrastructure',
    'network',
    'cloud_provider',
    'third_party',
    'people',
    'facility',
    'payment_rail',
    'other'
  ) NOT NULL,

  dependency_name VARCHAR(255) NOT NULL,
  dependency_reference VARCHAR(255) NULL,

  internal_owner_user_id CHAR(36) NULL,
  third_party_id CHAR(36) NULL,

  criticality ENUM(
    'low',
    'medium',
    'high',
    'critical'
  ) NOT NULL,

  maximum_tolerable_downtime_minutes INT UNSIGNED NULL,
  recovery_strategy TEXT NULL,

  single_point_of_failure BOOLEAN NOT NULL DEFAULT FALSE,
  alternate_available BOOLEAN NOT NULL DEFAULT FALSE,

  status ENUM(
    'active',
    'inactive'
  ) NOT NULL DEFAULT 'active',

  metadata JSON NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  KEY idx_service_dependencies (
    tenant_id,
    critical_business_service_id,
    criticality
  )
);

CREATE TABLE IF NOT EXISTS operational_incidents (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  incident_reference VARCHAR(180) NOT NULL,
  title VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,

  incident_type ENUM(
    'technology',
    'cybersecurity',
    'third_party',
    'payment_processing',
    'data',
    'fraud',
    'facility',
    'people',
    'compliance',
    'other'
  ) NOT NULL,

  severity ENUM(
    'sev4',
    'sev3',
    'sev2',
    'sev1'
  ) NOT NULL,

  status ENUM(
    'detected',
    'triaged',
    'investigating',
    'mitigating',
    'monitoring',
    'resolved',
    'closed'
  ) NOT NULL DEFAULT 'detected',

  detected_at TIMESTAMP NOT NULL,
  started_at TIMESTAMP NULL,
  acknowledged_at TIMESTAMP NULL,
  mitigated_at TIMESTAMP NULL,
  resolved_at TIMESTAMP NULL,
  closed_at TIMESTAMP NULL,

  incident_commander_user_id CHAR(36) NULL,
  technical_lead_user_id CHAR(36) NULL,
  communications_lead_user_id CHAR(36) NULL,

  customer_impact BOOLEAN NOT NULL DEFAULT FALSE,
  regulatory_impact BOOLEAN NOT NULL DEFAULT FALSE,
  financial_impact_amount DECIMAL(18,2) NULL,
  financial_impact_currency CHAR(3) NULL,

  affected_customer_count BIGINT UNSIGNED NULL,
  affected_transaction_count BIGINT UNSIGNED NULL,

  regulator_notification_required BOOLEAN NOT NULL DEFAULT FALSE,
  customer_notification_required BOOLEAN NOT NULL DEFAULT FALSE,

  regulator_notified_at TIMESTAMP NULL,
  customers_notified_at TIMESTAMP NULL,

  root_cause_category VARCHAR(180) NULL,
  root_cause_summary TEXT NULL,

  metadata JSON NULL,

  created_by CHAR(36) NOT NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_operational_incident_reference (
    tenant_id,
    incident_reference
  ),

  KEY idx_operational_incident_status (
    tenant_id,
    status,
    severity,
    detected_at
  )
);

CREATE TABLE IF NOT EXISTS incident_affected_services (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  operational_incident_id CHAR(36) NOT NULL,
  critical_business_service_id CHAR(36) NOT NULL,

  impact_started_at TIMESTAMP NULL,
  impact_ended_at TIMESTAMP NULL,

  impact_description TEXT NULL,
  service_level_percentage DECIMAL(5,2) NULL,

  tolerance_breached BOOLEAN NOT NULL DEFAULT FALSE,
  breach_minutes INT UNSIGNED NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  UNIQUE KEY uq_incident_affected_service (
    operational_incident_id,
    critical_business_service_id
  )
);

CREATE TABLE IF NOT EXISTS incident_actions (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  operational_incident_id CHAR(36) NOT NULL,

  action_type ENUM(
    'investigation',
    'containment',
    'mitigation',
    'recovery',
    'communication',
    'regulatory',
    'customer_support',
    'follow_up'
  ) NOT NULL,

  title VARCHAR(255) NOT NULL,
  description TEXT NULL,

  priority ENUM(
    'low',
    'medium',
    'high',
    'critical'
  ) NOT NULL DEFAULT 'medium',

  status ENUM(
    'open',
    'in_progress',
    'blocked',
    'completed',
    'cancelled'
  ) NOT NULL DEFAULT 'open',

  assigned_to CHAR(36) NULL,
  due_at TIMESTAMP NULL,
  completed_at TIMESTAMP NULL,

  evidence_storage_key VARCHAR(1000) NULL,

  created_by CHAR(36) NOT NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  KEY idx_incident_actions (
    operational_incident_id,
    status,
    priority
  )
);

CREATE TABLE IF NOT EXISTS business_continuity_plans (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  critical_business_service_id CHAR(36) NOT NULL,

  plan_code VARCHAR(120) NOT NULL,
  plan_name VARCHAR(255) NOT NULL,
  version VARCHAR(80) NOT NULL,

  activation_criteria TEXT NOT NULL,
  recovery_strategy TEXT NOT NULL,
  communication_plan TEXT NULL,

  alternate_site_details TEXT NULL,
  manual_workaround_details TEXT NULL,
  restoration_sequence JSON NULL,

  status ENUM(
    'draft',
    'active',
    'superseded',
    'retired'
  ) NOT NULL DEFAULT 'draft',

  effective_from DATE NOT NULL,
  effective_to DATE NULL,

  created_by CHAR(36) NOT NULL,
  approved_by CHAR(36) NULL,
  approved_at TIMESTAMP NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_business_continuity_plan (
    tenant_id,
    plan_code,
    version
  )
);

CREATE TABLE IF NOT EXISTS resilience_test_exercises (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,

  exercise_reference VARCHAR(180) NOT NULL,
  exercise_name VARCHAR(255) NOT NULL,

  exercise_type ENUM(
    'tabletop',
    'simulation',
    'failover',
    'disaster_recovery',
    'cyber_recovery',
    'third_party_exit',
    'communications',
    'full_scale'
  ) NOT NULL,

  scope JSON NOT NULL,
  scenario TEXT NOT NULL,

  planned_start_at TIMESTAMP NOT NULL,
  planned_end_at TIMESTAMP NULL,

  actual_start_at TIMESTAMP NULL,
  actual_end_at TIMESTAMP NULL,

  status ENUM(
    'planned',
    'approved',
    'in_progress',
    'completed',
    'cancelled'
  ) NOT NULL DEFAULT 'planned',

  outcome ENUM(
    'not_assessed',
    'passed',
    'passed_with_actions',
    'failed'
  ) NOT NULL DEFAULT 'not_assessed',

  summary TEXT NULL,
  lessons_learned TEXT NULL,

  created_by CHAR(36) NOT NULL,
  approved_by CHAR(36) NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_resilience_exercise_reference (
    tenant_id,
    exercise_reference
  )
);

CREATE TABLE IF NOT EXISTS post_incident_reviews (
  id CHAR(36) PRIMARY KEY,
  tenant_id CHAR(36) NOT NULL,
  operational_incident_id CHAR(36) NOT NULL,

  review_reference VARCHAR(180) NOT NULL,

  executive_summary TEXT NOT NULL,
  timeline JSON NOT NULL,

  root_cause TEXT NOT NULL,
  contributing_factors JSON NULL,

  what_went_well JSON NULL,
  what_went_wrong JSON NULL,

  customer_impact_assessment TEXT NULL,
  regulatory_impact_assessment TEXT NULL,

  approved_by CHAR(36) NULL,
  approved_at TIMESTAMP NULL,

  created_by CHAR(36) NOT NULL,

  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_post_incident_review (
    tenant_id,
    operational_incident_id
  ),

  UNIQUE KEY uq_post_incident_review_reference (
    tenant_id,
    review_reference
  )
);
