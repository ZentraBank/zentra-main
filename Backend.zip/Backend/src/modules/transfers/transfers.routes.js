const router = require("express").Router();
const controller = require("./transfers.controller");
const schemas = require("./transfers.validation");
const validate = require("../../middleware/validate.middleware");

const {
  resolveTenantMiddleware,
} = require("../../middleware/tenant.middleware");

const {
  authenticate,
} = require("../../middleware/auth.middleware");

const {
  requireAllPermissions,
} = require("../../middleware/permission.middleware");

router.use(resolveTenantMiddleware);
router.use(authenticate);

router.post(
  "/",
  validate(schemas.createTransferSchema),
  requireAllPermissions("transfers.create"),
  controller.createOwn
);

router.get(
  "/me",
  validate(schemas.listTransfersSchema),
  requireAllPermissions("transfers.read_own"),
  controller.listOwn
);

router.get(
  "/me/:transferId",
  validate(schemas.transferIdSchema),
  requireAllPermissions("transfers.read_own"),
  controller.getOwn
);

module.exports = router;